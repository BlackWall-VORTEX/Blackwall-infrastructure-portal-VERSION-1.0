# BlackWall Portal — integração com a API

O frontend não inclui usuários, credenciais, ambientes ou resultados fictícios. Login e operações dependem da API real. O portal usa `/api` na mesma origem, encaminhado pelo Nginx ao serviço da API. O botão de configuração da API só aparece para administradores autenticados.

## Contrato esperado pelo frontend
- `POST /auth/login` JSON `{ "username": "...", "password": "..." }`; resposta recomendada `{ "user": { "id": "UUID", "username": "...", "display_name": "...", "role": "admin|user" } }` e cookie de sessão `HttpOnly` definido pelo servidor.
- `GET /auth/me` com o cookie de sessão enviado automaticamente pelo navegador; devolve usuário autenticado ou `{ "user": ... }`.
- `POST /auth/logout` invalida sessão/token se a estratégia da API exigir.
- `GET /users` e `POST /users` (admin only). Criação envia `username`, `display_name`, `password`, `role` (`admin` ou `user`) e `environment_limit`.
- `GET /audit` (admin only).
- `GET /health`, `GET /options`, `POST /provision`, `GET /provision/{id}`, `POST /provision/{id}/cancel`.
- `GET /environments`, `GET /environments/{id}`, `POST /environments/{id}/start`, `POST /environments/{id}/stop`, `DELETE /environments/{id}`.

Respostas de erro devem usar HTTP apropriado e JSON com `detail` ou `message`. A API precisa aplicar autorização e isolamento por conta em todas as rotas; o frontend não é uma barreira de segurança.

## Limitações explícitas
- O frontend só passa a operar depois que os endpoints acima forem implementados com estes formatos ou o adaptador seja ajustado ao contrato definitivo.
- A sessão é por cookie `HttpOnly`; em produção, use `Secure` em HTTPS, `SameSite` apropriado e proteção CSRF para operações mutáveis.
- A criação de usuário e auditoria só serão funcionais se a API suportar os endpoints correspondentes.
- A URL de Ingress, certificado, DNS, IP de Service/LoadBalancer e acesso à API ainda dependem da instalação/configuração do Kubernetes e da rede real.


## Autenticação atualizada (portal)

- O portal abre diretamente na tela de login e não exibe as páginas internas antes de validar a sessão em `GET /auth/me`.
- A sessão deve ser mantida por cookie `HttpOnly`, `Secure` em HTTPS e `SameSite` adequado; o JavaScript não armazena tokens em `localStorage` ou `sessionStorage`.
- Login: `POST /auth/login`; validação: `GET /auth/me`; saída: `POST /auth/logout`. As respostas de login podem trazer o perfil em `user`, mas não é necessário retornar token ao JavaScript.
- O proxy Nginx encaminha `/api/*` para o serviço Kubernetes `blackwall-api:8000`, mantendo portal e API como serviços separados e a sessão na mesma origem. Ajuste o nome/porta do serviço se o Deployment usar outro nome.
- O botão **API** só aparece para perfil `admin`; essa ocultação é apenas de interface. A API deve validar autorização administrativa em cada rota protegida.
- O administrador inicial não deve ser obrigado a trocar a senha no primeiro acesso. Usuários criados com senha temporária podem ter troca obrigatória, conforme a política implementada pela API.
- O portal não cria contas fictícias e não considera login ou ações bem-sucedidos sem confirmação da API.
