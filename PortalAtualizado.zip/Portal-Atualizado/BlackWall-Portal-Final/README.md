# BlackWall Portal — versão final do frontend

Portal estático (HTML/CSS/JS) preparado para autenticação e operações pela API real, sem modo demonstração. Inclui Dockerfile, Nginx e manifests Kubernetes iniciais para o namespace `blackwall-portal` com duas réplicas.

## Arquivos
- `index.html`, `style.css`, `script.js`: portal.
- `Dockerfile`, `nginx.conf`: imagem Nginx na porta 8080.
- `k8s/namespace.yaml`: namespace, Deployment e Service.
- `k8s/ingress.example.yaml`: exemplo a ajustar após o Ingress estar ativo.
- `CONTRATO-INTEGRACAO-PORTAL.md`: contrato esperado e dependências da API.

## Assets
Coloque os arquivos oficiais usados pelo portal em `assets/` mantendo os nomes referenciados pelo HTML/JS: `logo-pink.png`, `logo-red.png`, `logo-white.png`, `logo-blue.png`, `logo-blackwall.png` e `favicon.png`. Esta entrega não inventa ou redesenha a logo oficial. Se o arquivo não estava disponível nos anexos desta etapa, ele deve ser copiado da pasta assets original antes de construir a imagem.

## Build local
```bash
docker build -t blackwall-portal:1.0.0 .
docker run --rm -p 8080:8080 blackwall-portal:1.0.0
```

## Kubernetes
Instale e configure o Kubernetes no VM k3s primeiro. Depois, disponibilize a imagem ao nó/registry usado pelo cluster e ajuste o nome da imagem. `kubectl apply -f k8s/namespace.yaml`. O Ingress é exemplo e depende do DNS interno e do certificado TLS confiável.

## Segurança
O frontend nunca deve conter chaves da Abacus.AI, AWS ou Proxmox. As autorizações devem ser validadas no backend. Não exponha a API nem o Proxmox diretamente à internet.


## Login e integração com a API

O portal abre na tela de login. A sessão usa cookie HttpOnly enviado pelo navegador; não há token de sessão salvo no JavaScript. No Kubernetes, o Nginx encaminha `/api/` para `blackwall-api:8000`. Garanta que esse seja o nome e a porta reais do Service da API. O botão **API** fica disponível somente após autenticação de um administrador. A API continua responsável por autenticar e autorizar cada operação.
