const API_STORAGE_KEY = "blackwall_api_url";
// Sem IP padrão: o endereço da API precisa ser informado no botão API.
const DEFAULT_API_URL = `${window.location.origin}/api`;

const state = {
    language: "pt",
    theme: "white",
    provisioning: false,
    run: { cancelled: false },
    job: null,
    connectionStringValue: "",
    connectionRevealed: false,
};


// ============================================================
// API
// ============================================================

function getApiUrl() {
    const stored = localStorage.getItem(API_STORAGE_KEY);

    return stored
        ? stored.replace(/\/+$/, "")
        : DEFAULT_API_URL;
}


function normalizeApiUrl(value) {
    let valueToParse = value.trim();

    if (!valueToParse) {
        return "";
    }

    // Outro protocolo (ftp://, file://...) não é aceito.
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(valueToParse) && !/^https?:\/\//i.test(valueToParse)) {
        return "";
    }

    if (!/^https?:\/\//i.test(valueToParse)) {
        valueToParse = `http://${valueToParse}`;
    }

    try {
        const parsed = new URL(valueToParse);
        if (!/^https?:$/.test(parsed.protocol) || !parsed.hostname) {
            return "";
        }
        return parsed.toString().replace(/\/+$/, "");
    } catch {
        return "";
    }
}

function setApiUrl(url) {
    const normalized = normalizeApiUrl(url);

    if (normalized) {
        localStorage.setItem(API_STORAGE_KEY, normalized);
    } else {
        localStorage.removeItem(API_STORAGE_KEY);
    }

    return normalized;
}


// ============================================================
// ELEMENTS
// ============================================================

const apiButton = document.getElementById("apiButton");
const apiModal = document.getElementById("apiModal");
const closeApiModal = document.getElementById("closeApiModal");
const apiUrl = document.getElementById("apiUrl");
const saveApi = document.getElementById("saveApi");
const clearApi = document.getElementById("clearApi");
const testApi = document.getElementById("testApi");
const apiStatus = document.getElementById("apiStatus");

const languageButton = document.getElementById("languageButton");

const themeButton = document.getElementById("themeButton");
const themeMenu = document.getElementById("themeMenu");
const brandLogo = document.getElementById("brandLogo");

const provisionForm = document.getElementById("provisionForm");
const configurationCard = document.querySelector(".configuration-card");
const provisioningScreen = document.getElementById("provisioningScreen");
const globalFeedback = document.getElementById("globalFeedback");

// ============================================================
// AUTENTICAÇÃO REAL — sem usuários ou modos de demonstração
// Contrato esperado: POST /auth/login, GET /auth/me, POST /auth/logout
// ============================================================
const authModal = document.getElementById("authModal");
const authForm = document.getElementById("authForm");
const authError = document.getElementById("authError");
const loginButton = document.getElementById("loginButton");
const closeAuthModal = document.getElementById("closeAuthModal");
const profileArea = document.getElementById("profileArea");
const profileTrigger = document.getElementById("profileTrigger");
const profileMenu = document.getElementById("profileMenu");
const profileName = document.getElementById("profileName");
const profileId = document.getElementById("profileId");
const profileAvatarInitial = document.getElementById("profileAvatarInitial");
const profileMyEnvironments = document.getElementById("profileMyEnvironments");
const profileAllEnvironments = document.getElementById("profileAllEnvironments");
const profileUsers = document.getElementById("profileUsers");
const profileAudit = document.getElementById("profileAudit");
const profileLogout = document.getElementById("profileLogout");
const adminUsersModal = document.getElementById("adminUsersModal");
const adminAuditModal = document.getElementById("adminAuditModal");
const authState = { user: null };

// Sessão por cookie HttpOnly: o navegador envia o cookie, nunca guardamos token no JS.
function authHeaders(extra = {}) { return { ...extra }; }
function openAuthModal() {
    if (!authModal) return;
    authModal.classList.remove("hidden"); authError?.classList.add("hidden");
    document.getElementById("closeAuthModal")?.classList.add("hidden");
    document.getElementById("authIdentity")?.focus();
}
function closeAuth() { authModal?.classList.add("hidden"); authError?.classList.add("hidden"); }
function applyAuthenticatedUser(user) {
    if (!user || !user.id || !user.role) throw new Error("A API retornou um perfil de usuário inválido.");
    authState.user = user;
    const isAdmin = user.role === "admin";
    document.body.classList.add("authenticated");
    const displayName = user.display_name || user.name || user.username || "Usuário";
    profileName.textContent = displayName;
    profileId.textContent = `ID da conta: ${user.id}`;
    profileAvatarInitial.textContent = [...displayName][0]?.toLocaleUpperCase("pt-BR") || "U";
    profileMyEnvironments.classList.toggle("hidden", isAdmin);
    profileAllEnvironments.classList.toggle("hidden", !isAdmin);
    profileUsers.classList.toggle("hidden", !isAdmin);
    profileAudit.classList.toggle("hidden", !isAdmin);
    apiButton?.classList.toggle("hidden", !isAdmin);
    loginButton?.classList.add("hidden"); profileArea?.classList.remove("hidden");
}
function clearAuthenticatedUser() {
    authState.user = null;
    document.body.classList.remove("authenticated");
    profileArea?.classList.add("hidden"); loginButton?.classList.remove("hidden");
    apiButton?.classList.add("hidden"); profileMenu?.classList.add("hidden");
}
async function authenticatedFetch(path, options = {}) {
    const base = getApiUrl();
    if (!base) throw new Error("Configure o endereço da API no portal antes de entrar.");
    const response = await fetch(`${base}${path}`, { ...options, credentials: "include", headers: authHeaders({ "Content-Type": "application/json", ...(options.headers || {}) }) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) { const err = new Error(data.detail || data.message || `Falha HTTP ${response.status}`); err.status = response.status; throw err; }
    return data;
}
async function loadCurrentUser() {
    if (!getApiUrl()) { clearAuthenticatedUser(); openAuthModal(); return; }
    try { const data = await authenticatedFetch("/auth/me", { method: "GET", headers: {} }); applyAuthenticatedUser(data.user || data); closeAuth(); }
    catch { clearAuthenticatedUser(); openAuthModal(); }
}
loginButton?.addEventListener("click", openAuthModal);
closeAuthModal?.addEventListener("click", closeAuth);
authModal?.addEventListener("click", event => { if (event.target === authModal && !authState.user) event.preventDefault(); });
document.getElementById("togglePassword")?.addEventListener("click", () => {
    const field = document.getElementById("authPassword"); if (!field) return;
    const reveal = field.type === "password"; field.type = reveal ? "text" : "password";
    document.getElementById("togglePassword").setAttribute("aria-label", reveal ? "Ocultar senha" : "Mostrar senha");
});
profileTrigger?.addEventListener("click", () => { const opening = profileMenu.classList.contains("hidden"); profileMenu.classList.toggle("hidden", !opening); profileTrigger.setAttribute("aria-expanded", String(opening)); });
document.addEventListener("click", event => { if (profileArea && !profileArea.contains(event.target)) { profileMenu?.classList.add("hidden"); profileTrigger?.setAttribute("aria-expanded", "false"); } });
authForm?.addEventListener("submit", async event => {
    event.preventDefault(); authError.classList.add("hidden");
    const submit = document.getElementById("authSubmit"); submit.disabled = true;
    try {
        const base = getApiUrl(); if (!base) throw new Error("Configure o endereço da API antes de entrar.");
        const response = await fetch(`${base}/auth/login`, { method: "POST", credentials: "include", headers: authHeaders({ "Content-Type": "application/json" }), body: JSON.stringify({ username: document.getElementById("authIdentity").value.trim(), password: document.getElementById("authPassword").value }) });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.detail || data.message || "Usuário ou senha inválidos.");
        const userData = data.user || await authenticatedFetch("/auth/me", { method: "GET" });
        applyAuthenticatedUser(userData); closeAuth(); authForm.reset(); showGlobalFeedback("Login realizado com sucesso.");
    } catch (error) { authError.textContent = error.message || "Não foi possível entrar."; authError.classList.remove("hidden"); }
    finally { submit.disabled = false; }
});
profileLogout?.addEventListener("click", async () => {
    try { if (authState.user && getApiUrl()) await authenticatedFetch("/auth/logout", { method: "POST" }); } catch { /* limpar estado visual mesmo se a API estiver indisponível */ }
    clearAuthenticatedUser(); showGlobalFeedback("Sessão encerrada.");
});
profileMyEnvironments?.addEventListener("click", () => { profileMenu.classList.add("hidden"); environmentsButton?.click(); });
profileAllEnvironments?.addEventListener("click", () => { profileMenu.classList.add("hidden"); environmentsButton?.click(); });
profileUsers?.addEventListener("click", openAdminUsers);
profileAudit?.addEventListener("click", openAdminAudit);

async function openAdminUsers() {
    profileMenu?.classList.add("hidden"); adminUsersModal?.classList.remove("hidden");
    const list = document.getElementById("adminUsersList"); list.textContent = "Carregando usuários…";
    try {
        const data = await authenticatedFetch("/users", { method: "GET" });
        const users = Array.isArray(data) ? data : (data.items || data.users || []); list.replaceChildren();
        if (!users.length) { list.textContent = "Nenhum usuário retornado pela API."; return; }
        for (const user of users) { const row = document.createElement("div"); row.className = "admin-user-row"; const info = document.createElement("div"); const title = document.createElement("strong"); title.textContent = user.display_name || user.username; const meta = document.createElement("small"); meta.textContent = `${user.username} · ${user.role} · ${user.is_active === false ? "Bloqueado" : "Ativo"}`; info.append(title, meta); row.append(info); list.append(row); }
    } catch (error) { list.textContent = `Não foi possível consultar usuários: ${error.message}`; }
}
async function openAdminAudit() {
    profileMenu?.classList.add("hidden"); adminAuditModal?.classList.remove("hidden");
    const content = document.getElementById("adminAuditContent"); content.textContent = "Carregando auditoria…";
    try { const data = await authenticatedFetch("/audit", { method: "GET" }); const items = Array.isArray(data) ? data : (data.items || data.events || []); content.replaceChildren();
      if (!items.length) { content.textContent = "Nenhum evento de auditoria retornado pela API."; return; }
      for (const item of items) { const row = document.createElement("div"); row.className = "admin-user-row"; const title = document.createElement("strong"); title.textContent = item.action || item.event || "Evento"; const meta = document.createElement("small"); meta.textContent = `${item.created_at || item.timestamp || "Data indisponível"} · ${item.username || item.user_id || "Sistema"} · ${item.description || ""}`; row.append(title, meta); content.append(row); }
    } catch (error) { content.textContent = `Não foi possível consultar auditoria: ${error.message}`; }
}
document.getElementById("closeAdminUsers")?.addEventListener("click", () => adminUsersModal.classList.add("hidden"));
document.getElementById("closeAdminAudit")?.addEventListener("click", () => adminAuditModal.classList.add("hidden"));
adminUsersModal?.addEventListener("click", event => { if (event.target === adminUsersModal) adminUsersModal.classList.add("hidden"); });
adminAuditModal?.addEventListener("click", event => { if (event.target === adminAuditModal) adminAuditModal.classList.add("hidden"); });
document.getElementById("createUserForm")?.addEventListener("submit", async event => {
    event.preventDefault(); const status = document.getElementById("createUserStatus"); status.classList.add("hidden");
    const form = new FormData(event.currentTarget); const button = event.currentTarget.querySelector("button[type=submit]"); button.disabled = true;
    try {
        await authenticatedFetch("/users", { method: "POST", body: JSON.stringify({ username: form.get("username"), display_name: form.get("display_name"), password: form.get("password"), role: form.get("role"), environment_limit: Number(form.get("environment_limit")) }) });
        status.textContent = "Conta criada pela API."; status.classList.remove("hidden"); event.currentTarget.reset(); document.getElementById("newUserLimit").value = "2"; await openAdminUsers();
    } catch (error) { status.textContent = `Não foi possível criar a conta: ${error.message}`; status.classList.remove("hidden"); }
    finally { button.disabled = false; }
});
apiButton?.classList.add("hidden");
loadCurrentUser();

const progressBar = document.getElementById("progressBar");
const provisioningPercent =
    document.getElementById("provisioningPercent");
const provisioningDescription =
    document.getElementById("provisioningDescription");

const provisioningErrorMessage =
    document.getElementById("provisioningErrorMessage");

const provisioningErrorTitle =
    document.getElementById("provisioningErrorTitle");

const provisioningErrorDescription =
    document.getElementById("provisioningErrorDescription");

const backToStart =
    document.getElementById("backToStart");

const cancelProvision =
    document.getElementById("cancelProvision");

const cancelHint =
    document.getElementById("cancelHint");

const stages = [
    ...document.querySelectorAll(".stage")
];

const resultBox = document.getElementById("resultBox");

const copyConnection =
    document.getElementById("copyConnection");

const newEnvironment =
    document.getElementById("newEnvironment");


const networkSelect = document.getElementById("network");
const customNetworkInput = document.getElementById("customNetwork");

function getSelectedNetwork() {
    if (networkSelect.value === "custom") return customNetworkInput.value.trim();
    return networkSelect.value;
}

// Rede personalizada: exige IP com pontos + barra + máscara (ex.: 10.20.40.0/24).
const networkMessages = {
    pt: {
        missingMask: "Informe a rede com a máscara, ex.: 10.20.40.0/24",
        invalid: "Rede inválida. Use IP com pontos e máscara de /0 a /32, ex.: 10.20.40.0/24"
    },
    en: {
        missingMask: "Enter the network with the mask, e.g. 10.20.40.0/24",
        invalid: "Invalid network. Use a dotted IP and a mask from /0 to /32, e.g. 10.20.40.0/24"
    }
};

function customNetworkError(value) {
    const text = value.trim();
    if (!text.includes("/") || text.endsWith("/")) return "missingMask";

    const match = text.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\/(\d{1,2})$/);
    if (!match) return "invalid";

    const octets = match.slice(1, 5).map(Number);
    const prefix = Number(match[5]);
    if (octets.some(octet => octet > 255) || prefix > 32) return "invalid";

    return "";
}

// Mantém o campo personalizado, o "required" e a mensagem de aviso (!) em sincronia.
function syncNetworkField() {
    if (!networkSelect || !customNetworkInput) return;


    const custom = networkSelect.value === "custom";
    customNetworkInput.classList.toggle("hidden", !custom);
    customNetworkInput.required = custom;

    if (!custom) {
        customNetworkInput.value = "";
        customNetworkInput.setCustomValidity("");
        return;
    }

    const errorKey = customNetworkError(customNetworkInput.value);
    customNetworkInput.setCustomValidity(
        errorKey ? networkMessages[state.language === "en" ? "en" : "pt"][errorKey] : ""
    );
}

networkSelect?.addEventListener("change", syncNetworkField);

customNetworkInput?.addEventListener("input", () => {
    // Só números, ponto e barra.
    const cleaned = customNetworkInput.value.replace(/[^\d./]/g, "");
    if (cleaned !== customNetworkInput.value) customNetworkInput.value = cleaned;
    syncNetworkField();
});

// O reset do formulário não dispara "change": sincroniza depois que ele termina.
provisionForm?.addEventListener("reset", () => setTimeout(() => {
    syncNetworkField();
    syncEnvironmentName();
}, 0));

// ============================================================
// TRANSLATIONS
// ============================================================

const translations = {

    pt: {

        heroTitle:
            "Provisionamento de<br>ambientes MongoDB",

        heroDescription:
            "Configure os recursos necessários e solicite automaticamente um novo ambiente.",

        configTitle:
            "Configuração do ambiente",

        configDescription:
            "Defina os recursos totais do ambiente. A API fará a distribuição entre 3 nós.",

        securityText:
            "Ambiente isolado e provisionado automaticamente",

        provisionButton:
            "PROVISIONAR AMBIENTE",

        provisioningTitle:
            "Provisionando ambiente",

        provisioningDescription:
            "Aguarde enquanto o ambiente é preparado.",

        provisioningErrorTitle:
            "Não foi possível conectar à API.",

        provisioningErrorDescription:
            "Verifique se a API está online e se a URL configurada está correta.",

        backToStart:
            "VOLTAR AO INÍCIO",

        stages: [
            [
                "Validando configuração",
                "Verificando parâmetros solicitados"
            ],
            [
                "Criando infraestrutura",
                "Provisionando os recursos necessários"
            ],
            [
                "Configurando rede",
                "Aplicando configurações de conectividade"
            ],
            [
                "Configurando VMs",
                "Preparando os servidores"
            ],
            [
                "Instalando MongoDB",
                "Instalando e configurando o banco"
            ],
            [
                "Configurando Replica Set",
                "Configurando os nós do cluster"
            ],
            [
                "Executando testes",
                "Validando o ambiente provisionado"
            ]
        ],

        resultTitle:
            "Connection String criada",

        resultDescription:
            "O ambiente foi provisionado com sucesso.",

        connectionLabel:
            "Connection String",

        copy:
            "COPIAR",

        copied:
            "COPIADO",

        newEnvironment:
            "PROVISIONAR OUTRO AMBIENTE",

        apiTitle:
            "Configuração da API",

        apiDescription:
            "Informe o endereço do Backend/API que será utilizado pelo portal.",

        apiUrlLabel:
            "URL da API",

        save:
            "SALVAR",

        testApi:
            "TESTAR API",

        apiSaved:
            "URL da API salva.",

        apiDeleted:
            "URL da API removida.",

        apiEmpty:
            "Informe uma URL válida.",

        apiTesting:
            "Testando conexão...",

        apiSuccess:
            "API online e respondendo.",

        apiError:
            "Não foi possível conectar à API."

    },


    en: {

        heroTitle:
            "MongoDB environment<br>provisioning",

        heroDescription:
            "Configure the required resources and request a new environment automatically.",

        configTitle:
            "Environment configuration",

        configDescription:
            "Define the total resources for the environment. The API will distribute them across 3 nodes.",

        securityText:
            "Isolated environment provisioned automatically",

        provisionButton:
            "PROVISION ENVIRONMENT",

        provisioningTitle:
            "Provisioning environment",

        provisioningDescription:
            "Please wait while the environment is being prepared.",

        provisioningErrorTitle:
            "Could not connect to the API.",

        provisioningErrorDescription:
            "Check that the API is online and that the configured URL is correct.",

        backToStart:
            "BACK TO START",

        stages: [
            [
                "Validating configuration",
                "Checking requested parameters"
            ],
            [
                "Creating infrastructure",
                "Provisioning required resources"
            ],
            [
                "Configuring network",
                "Applying connectivity settings"
            ],
            [
                "Configuring VMs",
                "Preparing servers"
            ],
            [
                "Installing MongoDB",
                "Installing and configuring database"
            ],
            [
                "Configuring Replica Set",
                "Configuring cluster nodes"
            ],
            [
                "Running tests",
                "Validating the provisioned environment"
            ]
        ],

        resultTitle:
            "Connection String created",

        resultDescription:
            "The environment was successfully provisioned.",

        connectionLabel:
            "Connection String",

        copy:
            "COPY",

        copied:
            "COPIED",

        newEnvironment:
            "PROVISION ANOTHER ENVIRONMENT",

        apiTitle:
            "API configuration",

        apiDescription:
            "Enter the Backend/API address that will be used by the portal.",

        apiUrlLabel:
            "API URL",

        save:
            "SAVE",

        testApi:
            "TEST API",

        apiSaved:
            "API URL saved.",

        apiDeleted:
            "API URL removed.",

        apiEmpty:
            "Enter a valid URL.",

        apiTesting:
            "Testing connection...",

        apiSuccess:
            "API is online and responding.",

        apiError:
            "Could not connect to the API."

    }

};



// Tradução complementar para textos do portal que não estavam ligados ao dicionário principal.
// Os valores são aplicados por texto exato para não traduzir nomes informados pelos usuários.
const wholePortalTranslations = {
    "pt": {
        "SELF-SERVICE PROVISIONING": "SELF-SERVICE PROVISIONING",
        "Nome do ambiente": "Nome do ambiente",
        "Ex.: cliente-prod": "Ex.: cliente-prod",
        "Memória": "Memória",
        "Memória do ambiente (total)": "Memória do ambiente (total)",
        "vCPU do ambiente (total)": "vCPU do ambiente (total)",
        "Armazenamento do ambiente": "Armazenamento do ambiente",
        "Armazenamento": "Armazenamento",
        "Rede": "Rede",
        "Personalizado": "Personalizado",
        "Replica Set": "Replica Set",
        "1 nó": "1 nó",
        "3 nós": "3 nós",
        "5 nós": "5 nós",
        "Configuração da API": "Configuração da API",
        "Informe o endereço do Backend/API que será utilizado pelo portal.": "Informe o endereço do Backend/API que será utilizado pelo portal.",
        "URL da API": "URL da API",
        "APAGAR URL": "APAGAR URL",
        "SALVAR": "SALVAR",
        "TESTAR API": "TESTAR API",
        "PINK": "PINK",
        "RED": "RED",
        "WHITE": "WHITE",
        "BLUE": "BLUE",
        "TEMA": "TEMA",
        "API": "API",
        "Não foi possível copiar:": "Não foi possível copiar:",
        "Não foi possível copiar a Connection String.": "Não foi possível copiar a Connection String.",
        "Connection String": "Connection String",
    },
    "en": {
        "SELF-SERVICE PROVISIONING": "SELF-SERVICE PROVISIONING",
        "Nome do ambiente": "Environment name",
        "Ex.: cliente-prod": "E.g. customer-prod",
        "Memória": "Memory",
        "Memória do ambiente (total)": "Environment memory (total)",
        "vCPU do ambiente (total)": "Environment vCPU (total)",
        "Armazenamento do ambiente": "Environment storage",
        "Armazenamento": "Storage",
        "Rede": "Network",
        "Personalizado": "Custom",
        "Replica Set": "Replica Set",
        "1 nó": "1 node",
        "3 nós": "3 nodes",
        "5 nós": "5 nodes",
        "Configuração da API": "API configuration",
        "Informe o endereço do Backend/API que será utilizado pelo portal.": "Enter the Backend/API address used by the portal.",
        "URL da API": "API URL",
        "APAGAR URL": "CLEAR URL",
        "SALVAR": "SAVE",
        "TESTAR API": "TEST API",
        "PINK": "PINK",
        "RED": "RED",
        "WHITE": "WHITE",
        "BLUE": "BLUE",
        "TEMA": "THEME",
        "API": "API",
        "Não foi possível copiar:": "Could not copy:",
        "Não foi possível copiar a Connection String.": "Could not copy the Connection String.",
        "Connection String": "Connection String",
        'Configuração do ambiente': 'Environment configuration',
        'Defina os recursos que serão provisionados.': 'Define the resources to be provisioned.',
        'NOME DO AMBIENTE': 'ENVIRONMENT NAME',
        'VCPU': 'VCPU',
        'MEMÓRIA': 'MEMORY',
        'ARMAZENAMENTO': 'STORAGE',
        'REDE': 'NETWORK',
        'MONGODB': 'MONGODB',
        'Replica Set': 'Replica Set',
        '3 nós': '3 nodes',
        'Ambiente isolado e provisionado automaticamente': 'Isolated environment, provisioned automatically',
        'PROVISIONAR AMBIENTE': 'PROVISION ENVIRONMENT',
        'Configurando Replica Set': 'Configuring Replica Set',
        'Configurando os nós do cluster': 'Configuring cluster nodes',
        'COPIAR': 'COPY',
        'Nome do ambiente': 'Environment name',
        'Selecione': 'Select',
        'Personalizado': 'Custom',
        'Falha ao provisionar ambiente.': 'Failed to provision environment.',
        'Configuração da API': 'API configuration',
        'Informe o endereço do Backend/API que será utilizado pelo portal.': 'Enter the Backend/API URL used by the portal.',
        'URL da API': 'API URL',
        'APAGAR URL': 'CLEAR URL',
        'SALVAR': 'SAVE',
        'TESTAR API': 'TEST API',
        'Replica Set: 3 nós': 'Replica Set: 3 nodes'
    }
};


// Complemento do dicionário (texto-fonte em PT -> EN)
Object.assign(wholePortalTranslations.en, {
    "PROVISIONAMENTO SELF-SERVICE": "SELF-SERVICE PROVISIONING",
    "Ambiente criado no Proxmox": "Environment created on Proxmox", "Ambiente criado na AWS": "Environment created in AWS",
    "Criado na AWS por falta de capacidade local.": "Created in AWS because local capacity was insufficient.",
    "Infraestrutura local selecionada conforme a capacidade disponível.": "Local infrastructure selected based on available capacity.",
    "ROSA": "PINK", "VERMELHO": "RED", "BRANCO": "WHITE", "AZUL": "BLUE",
    "nós": "nodes", "PADRÃO": "DEFAULT",
    "Ex.: 100": "E.g. 100", "Ex.: 10.20.40.0/24": "E.g. 10.20.40.0/24",
    "http://IP:<porta>": "http://IP:<port>",
    "AJUDA": "HELP",
    "Como configurar seu ambiente": "How to configure your environment",
    "Entenda o que cada campo define antes de solicitar o provisionamento.": "Understand what each field defines before requesting provisioning.",
    "O que é um nó?": "What is a node?",
    "Um nó é uma instância (máquina virtual) que participa do Replica Set do MongoDB. Com três nós, o conjunto tem três instâncias que cooperam para manter cópias consistentes dos dados e melhorar a disponibilidade.": "A node is an instance (virtual machine) participating in the MongoDB Replica Set. With three nodes, the set has three instances that cooperate to maintain consistent copies of data and improve availability.",
    "Os recursos são por nó": "Resources are for the whole environment",
    "vCPU, memória e armazenamento informados no formulário representam o total do ambiente completo. O Replica Set terá sempre 3 nós. A API calculará e distribuirá esses recursos entre os três nós conforme as regras de provisionamento.": "The vCPU, memory, and storage entered in the form represent the total resources for the entire environment. The Replica Set always has 3 nodes. The API calculates and distributes these resources across the three nodes according to provisioning rules.",
    "O que preencher": "What to enter",
    "Nome do ambiente:": "Environment name:", "identificador, por exemplo cliente-prod.": "identifier, for example customer-prod.",
    "vCPU:": "vCPU:", "capacidade total de processamento do ambiente.": "total processing capacity for the environment.",
    "Memória:": "Memory:", "RAM total do ambiente.": "total RAM for the environment.",
    "Armazenamento:": "Storage:", "espaço total em disco do ambiente.": "total disk space for the environment.",
    "Rede:": "Network:", "rede à qual as máquinas serão conectadas.": "network the machines will connect to.",
    "MongoDB:": "MongoDB:", "versão a instalar.": "version to install.",
    "Replica Set:": "Replica Set:", "quantidade de nós do conjunto.": "number of nodes in the set.",
    "Antes de provisionar": "Before provisioning",
    "A API verificará a capacidade local e as regras de destino e custo. Preencher os recursos não garante disponibilidade; a solicitação pode ser recusada se não houver capacidade ou se as regras configuradas não forem atendidas.": "The API checks local capacity and placement and cost rules. Entering resources does not guarantee availability; the request may be rejected if capacity is unavailable or configured rules are not met.",
    "CANCELAR PROVISIONAMENTO": "CANCEL PROVISIONING",
    "Não foi possível comunicar com a API. Verifique a conexão e o endereço configurado.": "Could not communicate with the API. Check the connection and the configured address.",
    "Cancelando... desfazendo o que foi criado.": "Cancelling... undoing what was created.",
    "Cancelar não é mais possível nesta etapa.": "Cancelling is no longer possible at this stage.",
    "A API não encontrou este provisionamento.": "The API could not find this provisioning.",
    "Provisionamento cancelado.": "Provisioning cancelled.",
    "A solicitação foi cancelada.": "The request was cancelled.",
    "CANCELADO": "CANCELLED",
    "Deseja cancelar o provisionamento deste ambiente?": "Do you want to cancel provisioning this environment?",
    "Não foi possível cancelar o provisionamento.": "Could not cancel the provisioning.",
    "A API não oferece cancelamento.": "The API does not support cancellation.",
    "VOLTAR AO INÍCIO": "BACK TO START", "ERRO": "ERROR",
    "Configure o endereço da API antes de provisionar.": "Set the API address before provisioning.",
    "A API informou que o provisionamento falhou.": "The API reported that provisioning failed.",
    "A API não concluiu o provisionamento dentro do tempo esperado.": "The API did not complete provisioning within the expected time.",
    "A API iniciou a solicitação, mas não informou um endereço de status (statusUrl) nem um ID de acompanhamento.": "The API started the request but did not provide a status address (statusUrl) or a tracking ID."
});

// Sincroniza automaticamente os textos de `translations` (pt -> en)
for (const key of Object.keys(translations.pt)) {
    const pt = translations.pt[key], en = translations.en[key];
    if (typeof pt === "string" && typeof en === "string") wholePortalTranslations.en[pt] = en;
}
translations.pt.stages.forEach((pair, i) => pair.forEach((text, j) => {
    wholePortalTranslations.en[text] = translations.en.stages[i][j];
}));

// Textos com valores variáveis (nomes, números) — traduzidos por padrão
const portalPatterns = [
    [/^API respondeu HTTP (\d+)$/, "The API responded with HTTP $1"],
    [/^A API respondeu com erro HTTP (\d+)\.$/, "The API responded with HTTP error $1."],
    [/^Não foi possível confirmar a conexão com a API em (\S+)\. Verifique o endereço, se o backend está ligado e se o CORS permite a origem do portal\.( A conexão excedeu o tempo limite\.)?$/,
        (m, base, timeout) => `Could not confirm the connection to the API at ${base}. Check the address, that the backend is running, and that CORS allows the portal origin.${timeout ? " The connection timed out." : ""}`]
];

function translatePortalText(text, language) {
    if (language !== "en") return text;
    const direct = wholePortalTranslations.en[text];
    if (direct) return direct;
    for (const [pattern, replacement] of portalPatterns) {
        if (pattern.test(text)) return text.replace(pattern, replacement);
    }
    return text;
}

const wholePortalTranslationTargets = [
    "body:not(.translation-skip)"
];

function applyWholePortalTranslations() {
    const language = state.language === "en" ? "en" : "pt";
    const dictionary = wholePortalTranslations[language];
    const protectedIds = new Set([
        "heroTitle", "heroDescription", "configTitle", "configDescription",
        "securityText", "provisionButtonText", "provisioningTitle",
        "provisioningDescription", "resultTitle", "resultDescription",
        "connectionLabel", "copyConnection", "newEnvironment",
        "apiModalTitle", "apiModalDescription", "saveApi", "testApi",
        "revealConnection", "aboutButton", "aboutTitle", "aboutDescription",
        "aboutValue1Title", "aboutValue1Text", "aboutValue2Title", "aboutValue2Text",
        "aboutValue3Title", "aboutValue3Text"
    ]);

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);

    for (const node of nodes) {
        const parent = node.parentElement;
        if (!parent || parent.closest("script, style, textarea, code, pre")) continue;
        if ([...protectedIds].some(id => parent.closest(`#${id}`))) continue;

        if (!node.hasOwnProperty("__bwOriginalText")) {
            Object.defineProperty(node, "__bwOriginalText", {
                value: node.nodeValue,
                writable: true,
                configurable: true
            });
        }

        const original = node.__bwOriginalText;
        const normalized = original.replace(/\s+/g, " ").trim();
        if (!normalized) continue;

        const translated = translatePortalText(normalized, language);
        if (translated && translated !== normalized) {
            const leading = original.match(/^\s*/)?.[0] || "";
            const trailing = original.match(/\s*$/)?.[0] || "";
            const nextValue = leading + translated + trailing;
            if (node.nodeValue !== nextValue) node.nodeValue = nextValue;
        } else if (language === "pt" && node.nodeValue !== original) {
            node.nodeValue = original;
        }
    }

    document.querySelectorAll("input[placeholder], input[title], button[title], [aria-label]").forEach(el => {
        for (const attr of ["placeholder", "title", "aria-label"]) {
            if (!el.hasAttribute(attr)) continue;
            const key = `bwOriginal${attr.replace(/[^a-z]/g, "")}`;
            if (!(key in el.dataset)) el.dataset[key] = el.getAttribute(attr);
            const original = el.dataset[key];
            const translated = translatePortalText(String(original).replace(/\s+/g, " ").trim(), language);
            el.setAttribute(attr, translated || original);
        }
    });
}

let wholePortalTranslationObserver;
function startWholePortalTranslationObserver() {
    if (wholePortalTranslationObserver) wholePortalTranslationObserver.disconnect();
    wholePortalTranslationObserver = new MutationObserver(() => {
        if (wholePortalTranslationObserver) {
            wholePortalTranslationObserver.disconnect();
            applyWholePortalTranslations();
            wholePortalTranslationObserver.observe(document.body, { childList: true, subtree: true });
        }
    });
    wholePortalTranslationObserver.observe(document.body, { childList: true, subtree: true });
}

// ============================================================
// LANGUAGE
// ============================================================

function updateLanguage() {

    const t = translations[state.language];

    const storageLabelText = document.getElementById("storageLabelText");
    if (storageLabelText) storageLabelText.textContent = state.language === "en" ? "Environment storage" : "Armazenamento do ambiente";

    document.getElementById("heroTitle").innerHTML =
        t.heroTitle;

    document.getElementById("heroDescription").textContent =
        t.heroDescription;

    document.getElementById("configTitle").textContent =
        t.configTitle;

    document.getElementById("configDescription").textContent =
        t.configDescription;

    document.getElementById("securityText").textContent =
        t.securityText;

    document.getElementById("provisionButtonText").textContent =
        t.provisionButton;

    document.getElementById("provisioningTitle").textContent =
        t.provisioningTitle;

    document.getElementById("provisioningDescription").textContent =
        t.provisioningDescription;

    document.getElementById("resultTitle").textContent =
        t.resultTitle;

    document.getElementById("resultDescription").textContent =
        t.resultDescription;

    document.getElementById("connectionLabel").textContent =
        t.connectionLabel;

    document.getElementById("copyConnection").textContent =
        t.copy;
    if (revealConnectionButton) {
        revealConnectionButton.textContent = state.connectionRevealed
            ? (state.language === "en" ? "HIDE" : "OCULTAR")
            : (state.language === "en" ? "REVEAL" : "REVELAR");
    }

    const aboutCopy = state.language === "en" ? {
        button: "ABOUT US", title: "About us",
        description: "BlackWall develops solutions to simplify and standardize infrastructure operations, focusing on automation, security, and efficiency.",
        v1: "Automation", t1: "Fewer manual tasks and greater consistency.",
        v2: "Standardization", t2: "Clear processes and reproducible environments.",
        v3: "Infrastructure", t3: "Organized provisioning designed to evolve."
    } : {
        button: "SOBRE NÓS", title: "Sobre nós",
        description: "A BlackWall desenvolve soluções para simplificar e padronizar operações de infraestrutura, com foco em automação, segurança e eficiência.",
        v1: "Automação", t1: "Menos tarefas manuais e mais consistência.",
        v2: "Padronização", t2: "Processos claros e ambientes reproduzíveis.",
        v3: "Infraestrutura", t3: "Provisionamento organizado e preparado para evoluir."
    };
    const aboutButtonEl = document.getElementById("aboutButton");
    if (aboutButtonEl) aboutButtonEl.textContent = aboutCopy.button;
    const closeAboutEl = document.getElementById("closeAbout");
    if (closeAboutEl) closeAboutEl.setAttribute("aria-label", state.language === "en" ? "Close" : "Fechar");
    for (const [id, value] of Object.entries({
        aboutTitle: aboutCopy.title, aboutDescription: aboutCopy.description,
        aboutValue1Title: aboutCopy.v1, aboutValue1Text: aboutCopy.t1,
        aboutValue2Title: aboutCopy.v2, aboutValue2Text: aboutCopy.t2,
        aboutValue3Title: aboutCopy.v3, aboutValue3Text: aboutCopy.t3
    })) {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    }

    document.getElementById("newEnvironment").textContent =
        t.newEnvironment;

    document.getElementById("apiModalTitle").textContent =
        t.apiTitle;

    document.getElementById("apiModalDescription").textContent =
        t.apiDescription;

    document.querySelector(
        'label[for="apiUrl"]'
    ).textContent = t.apiUrlLabel;

    document.getElementById("saveApi").textContent =
        t.save;

    document.getElementById("testApi").textContent =
        t.testApi;

    stages.forEach((stage, index) => {

        const strong = stage.querySelector("strong");
        const span = stage.querySelector("span");

        strong.textContent = t.stages[index][0];
        span.textContent = t.stages[index][1];

    });

    languageButton.textContent =
        state.language === "pt" ? "PT" : "EN";

    document.documentElement.lang = state.language === "pt" ? "pt-BR" : "en";
    document.title = state.language === "pt"
        ? "BLACKWALL | Provisionamento Self-Service"
        : "BLACKWALL | Self-Service Provisioning";

    applyWholePortalTranslations();
    updateEnvironmentLanguage();
    updateHelpLanguage();
    syncNetworkField();
    syncEnvironmentName();
}


languageButton.addEventListener(
    "click",
    () => {

        state.language =
            state.language === "pt" ? "en" : "pt";

        updateLanguage();

    }
);


// ============================================================
// THEMES
// ============================================================

function applyTheme(theme) {

    state.theme = theme;

    document.body.dataset.theme = theme;

    brandLogo.src =
        theme === "blue"
            ? "assets/blue-logo.png"
            : `assets/logo-${theme}.png`;
    const apiModalLogo = document.getElementById("apiModalLogo");
    if (apiModalLogo) apiModalLogo.src = brandLogo.src;
    if (typeof aboutActive !== "undefined" && aboutActive && typeof resizeAboutCanvas === "function") {
        resizeAboutCanvas();
    }

}


themeButton.addEventListener(
    "click",
    (event) => {

        event.stopPropagation();

        themeMenu.classList.toggle("hidden");

    }
);


document.querySelectorAll(
    ".theme-menu button"
).forEach(button => {

    button.addEventListener(
        "click",
        () => {

            applyTheme(
                button.dataset.theme
            );

            themeMenu.classList.add("hidden");

        }
    );

});


document.addEventListener(
    "click",
    () => {

        themeMenu.classList.add("hidden");

    }
);


// ============================================================
// API MODAL
// ============================================================

apiButton?.addEventListener(
    "click",
    () => {

        apiUrl.value = getApiUrl();
        apiStatus.textContent = "";

        apiStatus.className = "api-status";

        apiModal.classList.remove("hidden");
        openApiLogoAnimation();

    }
);


closeApiModal.addEventListener(
    "click",
    () => {

        apiModal.classList.add("hidden");
        closeApiLogoAnimation();

    }
);


apiModal.addEventListener(
    "click",
    (event) => {

        if (event.target === apiModal) {

            apiModal.classList.add("hidden");
            closeApiLogoAnimation();

        }

    }
);


clearApi.addEventListener(
    "click",
    () => {

        localStorage.removeItem(API_STORAGE_KEY);
        apiUrl.value = "";
        apiStatus.textContent = translations.pt.apiDeleted;
        apiStatus.className = "api-status success";

    }
);


saveApi.addEventListener(
    "click",
    () => {

        // Salvar vazio significa remover a URL armazenada.
        if (!apiUrl.value.trim()) {
            localStorage.removeItem(API_STORAGE_KEY);
            apiUrl.value = "";
            apiStatus.textContent =
                translations.pt.apiDeleted;
            apiStatus.className = "api-status success";
            return;
        }

        const normalized = setApiUrl(apiUrl.value);

        if (!normalized) {
            apiStatus.textContent =
                translations.pt.apiEmpty;
            apiStatus.className = "api-status error";
            return;
        }

        apiUrl.value = normalized;
        apiStatus.textContent =
            translations.pt.apiSaved;
        apiStatus.className = "api-status success";
    }
);


testApi.addEventListener(
    "click",
    async () => {
        const normalized = setApiUrl(apiUrl.value);

        if (!normalized) {
            apiStatus.textContent = translations.pt.apiEmpty;
            apiStatus.className = "api-status error";
            return;
        }

        apiUrl.value = normalized;
        apiStatus.textContent = translations.pt.apiTesting;
        apiStatus.className = "api-status loading";
        testApi.disabled = true;

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);

        try {
            let response = await fetch(`${normalized}/health`, {
                method: "GET",
                headers: { "Accept": "application/json, text/plain, */*" },
                signal: controller.signal,
                cache: "no-store"
            });

            /* Some backends expose the root endpoint instead of /health. */
            if (!response.ok && response.status === 404) {
                response = await fetch(normalized, {
                    method: "GET",
                    headers: { "Accept": "application/json, text/plain, */*" },
                    signal: controller.signal,
                    cache: "no-store"
                });
            }

            if (!response.ok) {
                throw new Error(`A API respondeu HTTP ${response.status} em ${response.url || normalized}.`);
            }

            apiStatus.textContent = translations.pt.apiSuccess;
            apiStatus.className = "api-status success";
        } catch (error) {
            console.error("Erro ao testar API:", error);
            if (error?.name === "AbortError") {
                apiStatus.textContent = "Tempo limite excedido: a API não respondeu em 5 segundos. Confira se o servidor está ligado e se a porta está correta.";
            } else if (error instanceof TypeError) {
                apiStatus.textContent = "Falha de rede/CORS. Confira a URL e a porta da API, se o backend está ligado e se o CORS permite a origem deste portal. Veja F12 > Console para o detalhe.";
            } else {
                apiStatus.textContent = error?.message || translations.pt.apiError;
            }
            apiStatus.className = "api-status error";
        } finally {
            clearTimeout(timeout);
            testApi.disabled = false;
        }
    }
);


// ============================================================
// PROVISIONING
// ============================================================

// ============================================================
// NOME DO AMBIENTE — vira nome de VM/estado do Terraform:
// 3 a 32 caracteres, minúsculas, números e hífen (começa com letra, termina com letra/número).
// ============================================================

const environmentNameInput = document.getElementById("environmentName");
const ENVIRONMENT_NAME_PATTERN = /^[a-z][a-z0-9-]{1,30}[a-z0-9]$/;
const environmentNameMessages = {
    pt: "Use de 3 a 32 caracteres: letras minúsculas, números e hífen. Comece com letra e termine com letra ou número.",
    en: "Use 3 to 32 characters: lowercase letters, numbers and hyphens. Start with a letter and end with a letter or number."
};

function syncEnvironmentName() {
    if (!environmentNameInput) return;

    const valid = ENVIRONMENT_NAME_PATTERN.test(environmentNameInput.value);
    environmentNameInput.setCustomValidity(
        valid ? "" : environmentNameMessages[state.language === "en" ? "en" : "pt"]
    );
}

environmentNameInput?.addEventListener("input", () => {
    // Minúsculas, sem acentos, espaço vira hífen, só letras/números/hífen.
    const cleaned = environmentNameInput.value
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "")
        .slice(0, 32);

    if (cleaned !== environmentNameInput.value) environmentNameInput.value = cleaned;
    syncEnvironmentName();
});

// ============================================================
// ACOMPANHAMENTO — tempo limite, tolerância a falhas e retomada
// ============================================================

const POLL_INTERVAL_MS = 2000;               // consulta a cada 2 s
const POLL_MAX_MS = 60 * 60 * 1000;          // por até 60 minutos
const POLL_MAX_FAILURES = 15;                // falhas seguidas toleradas (~30 s)
const ACTIVE_JOB_KEY = "blackwall_active_job";
const ACTIVE_JOB_MAX_AGE_MS = 24 * 60 * 60 * 1000;

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function saveActiveJob(statusUrl) {
    try {
        localStorage.setItem(ACTIVE_JOB_KEY, JSON.stringify({
            statusUrl,
            apiBase: getApiUrl(),
            startedAt: Date.now()
        }));
    } catch {
        // Sem armazenamento disponível: apenas não retoma depois de atualizar.
    }
}

function clearActiveJob() {
    try {
        localStorage.removeItem(ACTIVE_JOB_KEY);
    } catch {
        // ignorado
    }
}

function loadActiveJob() {
    try {
        const saved = JSON.parse(localStorage.getItem(ACTIVE_JOB_KEY) || "null");
        if (!saved || typeof saved.statusUrl !== "string") return null;

        if (Date.now() - Number(saved.startedAt) > ACTIVE_JOB_MAX_AGE_MS) {
            clearActiveJob();
            return null;
        }

        const base = getApiUrl();
        if (!base || saved.apiBase !== base) return null;
        if (new URL(saved.statusUrl).origin !== new URL(base).origin) return null;

        return saved;
    } catch {
        return null;
    }
}

// ============================================================
// ENDPOINTS OPCIONAIS — usados só se a API oferecer (veja API-ENDPOINTS.md)
//   GET  /options                  -> preenche as listas do formulário
//   POST /provision/{id}/cancel    -> botão CANCELAR (se a API informar can_cancel)
// Se o endpoint não existir (404/405/501) ou falhar, o portal ignora e segue normal.
// ============================================================

const OPTIONAL_UNSUPPORTED = [404, 405, 501];

async function optionalGet(path, timeoutMs = 4000) {
    const base = getApiUrl();
    if (!base) return null;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
        const response = await fetch(`${base}${path}`, {
            method: "GET",
            headers: { Accept: "application/json" },
            signal: controller.signal,
            cache: "no-store"
        });
        const data = await readApiResponse(response);
        return { status: response.status, ok: response.ok, data };
    } catch {
        return null;
    } finally {
        clearTimeout(timeout);
    }
}

function fillSelect(select, items, labelOf) {
    if (!select || !Array.isArray(items)) return;
    const values = items.map(String).filter(value => value.trim() !== "");
    if (!values.length) return;

    const keep = values.includes(select.value) ? select.value : values[0];
    select.replaceChildren(...values.map(value => {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = labelOf(value);
        option.defaultSelected = value === keep;
        return option;
    }));
    select.value = keep;
}

function applyPortalOptions(options) {
    if (!options || typeof options !== "object" || Array.isArray(options)) return;

    // Listas permitidas pelo portal: não adicionar valores extras vindos da API.
    const vcpuOptions = [1, 2, 3, 6, 12];
    const memoryOptions = [1, 2, 4, 6, 12, 24, 32, 64];
    fillSelect(document.getElementById("vcpu"), vcpuOptions, value => `${value} vCPU`);
    fillSelect(document.getElementById("memory"), memoryOptions, value => `${value} GB`);
    fillSelect(document.getElementById("mongodbVersion"), options.mongodb_versions, value => `MongoDB ${value}`);

    const storage = document.getElementById("storage");
    if (options.storage_gb && typeof options.storage_gb === "object") {
        const limit = value => {
            const number = (typeof value === "number" || (typeof value === "string" && value.trim() !== "")) ? Number(value) : NaN;
            return Number.isFinite(number) && number > 0 ? number : null;
        };
        const min = limit(options.storage_gb.min);
        const max = limit(options.storage_gb.max);

        // Só aplica se o intervalo resultante for coerente.
        if ((min ?? Number(storage.min)) <= (max ?? Number(storage.max))) {
            if (min !== null) storage.min = min;
            if (max !== null) storage.max = max;
        }
    }

    // Redes de clientes permitidas pela topologia documentada. VLAN 40 (portal/API/k3s),
    // VLAN 99 (gerência) e VLAN 2 (WAN) nunca são oferecidas como rede de banco.
    const allowedNetworks = ["10.20.10.0/24", "10.20.20.0/24", "10.20.30.0/24"];
    const current = networkSelect.value;
    const keep = allowedNetworks.includes(current) ? current : allowedNetworks[0];
    networkSelect.replaceChildren(...allowedNetworks.map((cidr, index) => {
        const option = document.createElement("option");
        option.value = cidr;
        option.textContent = cidr;
        option.defaultSelected = cidr === keep;
        return option;
    }));
    networkSelect.value = keep;
    syncNetworkField();
}

async function loadPortalOptions() {
    const result = await optionalGet("/options");
    if (result && result.ok) applyPortalOptions(result.data);
}

// Recarrega as opções quando a URL da API for salva ou testada.
saveApi.addEventListener("click", () => setTimeout(loadPortalOptions, 0));
testApi.addEventListener("click", () => setTimeout(loadPortalOptions, 0));

// O botão só aparece quando a API informa sobre cancelamento (can_cancel / cancel_url).
// can_cancel=false NÃO esconde o botão: ele fica visível, porém desativado (ocioso).
function renderCancelButton() {
    const job = state.job;
    const known = Boolean(job && job.cancelKnown);

    const rollingBack = known && job.cancelling && job.cancelAccepted;

    cancelProvision.classList.toggle("hidden", !known);
    cancelHint.classList.toggle("hidden", !known || (job.canCancel && !rollingBack));
    cancelHint.textContent = rollingBack
        ? "Cancelando... desfazendo o que foi criado."
        : "Cancelar não é mais possível nesta etapa.";
    cancelProvision.disabled = known && (!job.canCancel || job.cancelling);
}

function hideCancelButton() {
    cancelProvision.disabled = false;
    cancelProvision.classList.add("hidden");
    cancelHint.classList.add("hidden");
}

function updateJobCapabilities(data) {
    if (!data || typeof data !== "object" || !state.job) return;

    const job = state.job;
    if (job.cancelUnsupported) return;

    if (typeof data.cancel_url === "string" && data.cancel_url) {
        job.cancelUrl = data.cancel_url;
        job.canCancel = true;
        job.cancelKnown = true;
    }
    if (typeof data.can_cancel === "boolean") {
        job.canCancel = data.can_cancel;
        job.cancelKnown = true;
    }

    // A API informou que está cancelando (desfazendo o que foi criado).
    const status = normalizeStageStatus(data.status || data.state || data.result || data.phase);
    if (/cancelling|canceling/.test(status)) {
        job.cancelling = true;
        job.cancelAccepted = true;
        job.cancelKnown = true;
    }

    renderCancelButton();
}

function isApiCancelled(data) {
    const status = normalizeStageStatus(
        data?.status || data?.state || data?.result || data?.phase
    );

    return /cancelled|canceled/.test(status);
}

function showProvisioningCancelled(run = state.run) {
    run.cancelled = true;
    state.provisioning = false;
    state.job = null;

    clearActiveJob();
    hideCancelButton();

    showProvisioningError(
        new Error("A solicitação foi cancelada."),
        {
            title: "Provisionamento cancelado.",
            percent: "CANCELADO"
        }
    );
}

function resolveCancelUrl() {
    const job = state.job;
    if (!job) return "";

    try {
        if (job.cancelUrl) return new URL(job.cancelUrl, getApiUrl()).toString();
        if (job.statusUrl) return `${job.statusUrl.replace(/\/+$/, "")}/cancel`;
    } catch {
        // URL inválida: sem cancelamento.
    }
    return "";
}

cancelProvision.addEventListener("click", async () => {
    if (!state.job || !state.provisioning || !state.job.canCancel || state.job.cancelling) return;

    const say = text => translatePortalText(text, state.language);
    if (!window.confirm(say("Deseja cancelar o provisionamento deste ambiente?"))) return;

    const url = resolveCancelUrl();
    if (!url) return;

    const run = state.run;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    state.job.cancelling = true;
    renderCancelButton();

    let accepted = false;

    try {
        const response = await fetch(url, {
            method: "POST",
            headers: { Accept: "application/json" },
            signal: controller.signal,
            cache: "no-store"
        });

        if (OPTIONAL_UNSUPPORTED.includes(response.status)) {
            state.job.cancelUnsupported = true;
            state.job.cancelKnown = false;
            hideCancelButton();
            window.alert(say("A API não oferece cancelamento."));
            return;
        }

        if (!response.ok) {
            const data = await readApiResponse(response);
            const detail = typeof data?.message === "string" ? data.message : (typeof data?.detail === "string" ? data.detail : "");
            window.alert(say("Não foi possível cancelar o provisionamento.") + (detail ? `\n${detail}` : ""));
            return;
        }

        // Cancelamento aceito: a API desfaz o que foi criado. O portal continua
        // acompanhando e só mostra "cancelado" quando a API responder status "cancelled".
        accepted = true;
        state.job.cancelling = true;
        state.job.cancelAccepted = true;

        const body = await readApiResponse(response).catch(() => ({}));
        updateJobCapabilities(body);

        if (isApiCancelled(body)) {
            showProvisioningCancelled(run);
        } else {
            renderCancelButton();
        }
    } catch {
        window.alert(say("Não foi possível cancelar o provisionamento."));
    } finally {
        clearTimeout(timeout);
        if (!accepted && state.job && state.job.cancelKnown && !run.cancelled) {
            state.job.cancelling = false;
            renderCancelButton();
        }
    }
});

let provisioningAbortController = null;

function collectProvisioningPayload() {
    // Contrato da API Vortex:
    // POST /provision
    return {
        environment_name:
            document.getElementById("environmentName").value.trim(),

        vcpu:
            Number(document.getElementById("vcpu").value),

        memory_gb:
            Number(document.getElementById("memory").value),

        storage_gb:
            Number(document.getElementById("storage").value),

        network:
            getSelectedNetwork(),

        mongodb_version:
            document.getElementById("mongodbVersion").value,

        replica_set_nodes: 3
    };
}

function showProvisioningScreen() {
    // A configuração sai da tela e entra somente o acompanhamento do processo.
    configurationCard.classList.add("hidden");
    resultBox.classList.add("hidden");
    provisioningScreen.classList.remove("hidden");

    provisioningErrorMessage.classList.add("hidden");
    backToStart.classList.add("hidden");
    provisioningDescription.classList.remove("hidden");

    provisioningErrorTitle.textContent =
        translations.pt.provisioningErrorTitle;

    provisioningErrorDescription.textContent =
        translations.pt.provisioningErrorDescription;

    backToStart.textContent =
        translations.pt.backToStart;
}

function resetStages() {
    stages.forEach((stage, index) => {
        stage.classList.remove("active", "completed");
        if (index === 0) stage.classList.add("active");
    });
}

function setStage(index) {
    stages.forEach((stage, stageIndex) => {
        stage.classList.remove("active", "completed");
        if (stageIndex < index) stage.classList.add("completed");
        if (stageIndex === index) stage.classList.add("active");
    });
}

function updateProgress(percent) {
    const safePercent = Math.max(0, Math.min(100, Math.round(percent)));
    progressBar.style.width = `${safePercent}%`;
    provisioningPercent.textContent = `${safePercent}%`;
}

function finishProvisioning(data = {}) {
    const placement = document.getElementById("resultPlacement");
    const provider = String(data.provider || data.destination || data.placement || data.infrastructure_provider || "").toLowerCase();
    const placementReason = data.placement_reason || data.reason || data.destination_message || "";
    if (provider || placementReason) {
        const isAws = /aws|amazon|cloud/.test(provider);
        const title = document.getElementById("resultDestinationTitle");
        title.textContent = isAws
            ? (state.language === "en" ? "Environment created in AWS" : "Ambiente criado na AWS")
            : (state.language === "en" ? "Environment created on Proxmox" : "Ambiente criado no Proxmox");
        document.getElementById("resultPlacementReason").textContent = placementReason || (isAws
            ? (state.language === "en" ? "Created in AWS because local capacity was insufficient." : "Criado na AWS por falta de capacidade local.")
            : (state.language === "en" ? "Local infrastructure selected based on available capacity." : "Infraestrutura local selecionada conforme a capacidade disponível."));
        placement.classList.remove("hidden");
    } else {
        placement?.classList.add("hidden");
    }

    const connection =
        data.connectionString ||
        data.connection_string ||
        data.connectionUri ||
        data.connection_uri ||
        data.uri ||
        data.connection;

    if (connection) {
        state.connectionStringValue = String(connection);
        state.connectionRevealed = false;
        const connectionElement = document.getElementById("connectionString");
        connectionElement.textContent = state.connectionRevealed ? state.connectionStringValue : "••••••••••••••••••••••••••••";
        connectionElement.classList.toggle("connection-hidden-value", !state.connectionRevealed);
        const revealButton = document.getElementById("revealConnection");
        const copyButton = document.getElementById("copyConnection");
        if (revealButton) {
            revealButton.disabled = false;
            revealButton.textContent = state.language === "en" ? (state.connectionRevealed ? "HIDE" : "REVEAL") : (state.connectionRevealed ? "OCULTAR" : "REVELAR");
        }
        if (copyButton) copyButton.disabled = false;
    } else {
        state.connectionStringValue = "";
        const connectionElement = document.getElementById("connectionString");
        if (connectionElement) {
            connectionElement.textContent = state.language === "en" ? "Connection string not returned by API." : "A API não retornou a connection string.";
            connectionElement.classList.remove("connection-hidden-value");
        }
        if (revealConnectionButton) revealConnectionButton.disabled = true;
        const copyButton = document.getElementById("copyConnection");
        if (copyButton) copyButton.disabled = true;
    }

    // Quando terminar, a tela de progresso sai por completo e entra
    // uma tela limpa de sucesso com a Connection String.
    provisioningScreen.classList.add("hidden");
    hideCancelButton();
    resultBox.classList.remove("hidden");
    clearActiveJob();
    updateProgress(100);

    stages.forEach(stage => {
        stage.classList.remove("active");
        stage.classList.add("completed");
    });

}

function normalizeStageStatus(value) {
    return String(value || "")
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[_-]+/g, " ");
}

function stageIndexFromValue(value) {
    const status = normalizeStageStatus(value);
    if (!status) return -1;

    if (/valid|validat|configur/.test(status)) return 0;
    if (/create|provision|infrastructure|infra/.test(status)) return 1;
    if (/network|rede|connect/.test(status)) return 2;
    if (/vm|server|compute/.test(status)) return 3;
    if (/mongo|database|banco/.test(status)) return 4;
    if (/replica|cluster|node/.test(status)) return 5;
    if (/test|verify|health|check/.test(status)) return 6;
    return -1;
}

function applyApiStageState(data) {
    if (!data || typeof data !== "object") return;

    updateJobCapabilities(data);

    const stagesFromApi = Array.isArray(data.stages)
        ? data.stages
        : Array.isArray(data.steps)
            ? data.steps
            : null;

    if (stagesFromApi) {
        stages.forEach((stage, index) => {
            const item = stagesFromApi[index] || {};
            const status = normalizeStageStatus(
                typeof item === "string" ? item : item.status || item.state
            );

            stage.classList.remove("active", "completed");

            if (/complete|success|done|finished|ok/.test(status) || item.completed === true) {
                stage.classList.add("completed");
            } else if (/active|running|progress|processing|current/.test(status) || item.active === true) {
                stage.classList.add("active");
            }
        });
    }

    // A API Vortex usa step de 1 a 7; o DOM usa índice de 0 a 6.
    let index = -1;

    if (data.step !== undefined && Number.isFinite(Number(data.step))) {
        index = Number(data.step) - 1;
    } else {
        const rawIndex =
            data.stageIndex ?? data.stage_index ??
            data.stepIndex ?? data.step_index ??
            data.currentStageIndex ?? data.current_step_index;

        index = Number.isFinite(Number(rawIndex)) ? Number(rawIndex) : -1;

        if (index < 0) {
            index = stageIndexFromValue(
                data.currentStage ?? data.current_stage ??
                data.currentStep ?? data.current_step ??
                data.stage ?? data.status ?? data.state
            );
        }
    }

    if (index >= 0) {
        setStage(Math.min(index, stages.length - 1));
    }

    if (data.message && state.language === "pt") {
        provisioningDescription.textContent = data.message;
    }

    const rawProgress =
        data.progress ?? data.percentage ?? data.percent ?? data.progressPercent;

    if (rawProgress !== undefined && Number.isFinite(Number(rawProgress))) {
        updateProgress(Number(rawProgress));
    } else if (index >= 0) {
        updateProgress(((index + 1) / stages.length) * 90);
    }
}

function isApiFinished(data) {
    const status = normalizeStageStatus(
        data?.status || data?.state || data?.result || data?.phase
    );

    return data?.completed === true ||
        data?.success === true ||
        /complete|completed|success|successful|done|finished|ready/.test(status);
}

function isApiFailed(data) {
    const status = normalizeStageStatus(
        data?.status || data?.state || data?.result || data?.phase
    );

    return data?.success === false || /error|failed|failure|cancelled|canceled/.test(status);
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
    const controller = new AbortController();
    provisioningAbortController = controller;

    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal,
            cache: "no-store",
            headers: {
                Accept: "application/json, text/plain, */*",
                ...(options.headers || {})
            }
        });

        return response;
    } finally {
        clearTimeout(timeout);
    }
}

async function readApiResponse(response) {
    const text = await response.text();
    if (!text) return {};

    try {
        return JSON.parse(text);
    } catch {
        return { message: text };
    }
}

function extractStatusUrl(data, response) {
    const candidate =
        data?.statusUrl || data?.status_url || data?.statusURL ||
        data?.pollUrl || data?.poll_url || data?.url ||
        response?.headers?.get("Location");

    if (!candidate) return "";

    try {
        return new URL(candidate, getApiUrl()).toString();
    } catch {
        return "";
    }
}

function extractJobId(data) {
    return data?.jobId || data?.job_id || data?.operationId ||
        data?.operation_id || data?.provisioningId || data?.provisioning_id ||
        data?.id || "";
}

function showGlobalFeedback(message, type = "success") {
    if (!globalFeedback) return;
    globalFeedback.textContent = message;
    globalFeedback.className = `global-feedback ${type}`;
    globalFeedback.classList.remove("hidden");
    window.clearTimeout(showGlobalFeedback.timer);
    showGlobalFeedback.timer = window.setTimeout(() => globalFeedback.classList.add("hidden"), 2800);
}

// O portal não solicita aprovação manual da AWS. A API deve decidir automaticamente
// entre Proxmox e AWS, respeitando capacidade, habilitação e teto de custo.

async function startApiProvisioning(payload, run = state.run) {
    const base = getApiUrl();
    if (!base) return false;

    let response = await fetchWithTimeout(`${base}/provision`, {
        method: "POST",
        headers: authHeaders({ "Content-Type": "application/json" }),
        body: JSON.stringify(payload)
    });

    // Also accept a backend that exposes /api/provision.
    if (response.status === 404) {
        response = await fetchWithTimeout(`${base}/api/provision`, {
            method: "POST",
            headers: authHeaders({ "Content-Type": "application/json" }),
            body: JSON.stringify(payload)
        });
    }

    const data = await readApiResponse(response);

    if (!response.ok) {
        throw new Error(data?.message || data?.detail || `API respondeu HTTP ${response.status}`);
    }

    applyApiStageState(data);

    if (isApiFailed(data)) {
        throw new Error(data.message || "A API informou que o provisionamento falhou.");
    }

    if (isApiFinished(data)) {
        finishProvisioning(data);
        return true;
    }

    let statusUrl = extractStatusUrl(data, response);
    const jobId = extractJobId(data);

    if (!statusUrl && jobId) {
        const candidates = [
            `${base}/provision/${encodeURIComponent(jobId)}`,
            `${base}/status/${encodeURIComponent(jobId)}`,
            `${base}/provisioning/${encodeURIComponent(jobId)}`
        ];

        for (const candidate of candidates) {
            try {
                const probe = await fetchWithTimeout(candidate, { method: "GET" }, 6000);
                if (probe.status !== 404) {
                    statusUrl = candidate;
                    break;
                }
            } catch {
                // Try the next conventional endpoint.
            }
        }
    }

    if (!statusUrl) {
        throw new Error(
            "A API iniciou a solicitação, mas não informou um endereço de status (statusUrl) nem um ID de acompanhamento."
        );
    }

    if (state.job) state.job.statusUrl = statusUrl;
    saveActiveJob(statusUrl);

    if (data?.requires_authorization === true || data?.authorization_required === true || ["awaiting_authorization", "pending_authorization", "authorization_required", "awaiting_approval"].includes(String(data?.status || data?.state || "").toLowerCase().replace(/[ -]/g, "_"))) {
        throw new Error("Contrato incompatível: a API solicitou autorização manual da AWS. O portal espera decisão automática de destino e validação do teto de custo no backend.");
    }

    await pollApiStatus(statusUrl, run);
    return true;
}

async function pollApiStatus(statusUrl, run = state.run) {
    const deadline = Date.now() + POLL_MAX_MS;
    let failures = 0;

    while (Date.now() < deadline) {
        if (run.cancelled) return;

        let response;
        let data;

        try {
            response = await fetchWithTimeout(statusUrl, { method: "GET" }, 10000);
            data = await readApiResponse(response);
        } catch (error) {
            if (run.cancelled) return;
            // Falha de rede passageira: tenta de novo antes de desistir.
            if (++failures >= POLL_MAX_FAILURES) throw error;
            await sleep(POLL_INTERVAL_MS);
            continue;
        }

        if (run.cancelled) return;

        if (!response.ok) {
            const message = data?.message || data?.detail || `API respondeu HTTP ${response.status}`;

            if (response.status === 404) {
                const notFound = new Error("A API não encontrou este provisionamento.");
                notFound.clearJob = true;
                throw notFound;
            }

            const transient = response.status >= 500 || response.status === 408 || response.status === 429;
            if (!transient || ++failures >= POLL_MAX_FAILURES) throw new Error(message);

            await sleep(POLL_INTERVAL_MS);
            continue;
        }

        failures = 0;
        applyApiStageState(data);

        if (data?.requires_authorization === true || data?.authorization_required === true || ["awaiting_authorization", "pending_authorization", "authorization_required", "awaiting_approval"].includes(String(data?.status || data?.state || "").toLowerCase().replace(/[ -]/g, "_"))) {
            throw new Error("Contrato incompatível: a API está aguardando autorização manual. O provisionamento deve seguir automaticamente após a decisão de destino e a validação de custos no backend.");
        }

        if (isApiCancelled(data)) {
            showProvisioningCancelled(run);
            return;
        }

        if (isApiFailed(data)) {
            const failed = new Error(data.message || "A API informou que o provisionamento falhou.");
            failed.clearJob = true;
            throw failed;
        }

        if (isApiFinished(data)) {
            finishProvisioning(data);
            return;
        }

        await sleep(POLL_INTERVAL_MS);
    }

    const expired = new Error("A API não concluiu o provisionamento dentro do tempo esperado.");
    expired.clearJob = true;
    throw expired;
}

// Ao abrir/atualizar a página, volta para o acompanhamento de um provisionamento em andamento.
function resumeActiveJob() {
    if (state.provisioning) return;

    const saved = loadActiveJob();
    if (!saved) return;

    const run = state.run = { cancelled: false };
    state.job = { statusUrl: saved.statusUrl, cancelUrl: "", canCancel: false, cancelKnown: false, cancelling: false, cancelAccepted: false };
    state.provisioning = true;

    showProvisioningScreen();
    resetStages();
    updateProgress(0);

    pollApiStatus(saved.statusUrl, run).catch(error => {
        if (run.cancelled) return;
        if (error?.clearJob) clearActiveJob();
        showProvisioningError(error);
        state.provisioning = false;
    });
}

// Erros crus do navegador ("Failed to fetch", abort) viram uma mensagem clara.
function friendlyError(error) {
    if (error && (error.name === "TypeError" || error.name === "AbortError")) {
        const friendly = new Error("Não foi possível comunicar com a API. Verifique a conexão e o endereço configurado.");
        friendly.clearJob = error.clearJob;
        return friendly;
    }
    return error;
}

function showProvisioningError(error, options = {}) {
    if (!options.title) console.error("Erro no provisionamento:", error);
    error = friendlyError(error);

    hideCancelButton();

    stages.forEach(stage => stage.classList.remove("active"));

    provisioningPercent.textContent = options.percent || "ERRO";
    progressBar.style.width = "0%";

    provisioningDescription.classList.add("hidden");
    provisioningErrorMessage.classList.remove("hidden");
    backToStart.classList.remove("hidden");

    provisioningErrorTitle.textContent =
        options.title || translations.pt.provisioningErrorTitle;

    provisioningErrorDescription.textContent =
        error?.message || translations.pt.provisioningErrorDescription;
}

async function verifyApiConnection() {
    const base = getApiUrl();
    if (!base) throw new Error("Configure o endereço da API antes de provisionar.");

    // Check common health endpoints before sending any provisioning request.
    const endpoints = [`${base}/health`, `${base}/`];
    let lastError = null;
    let unhealthy = null;

    for (const endpoint of endpoints) {
        try {
            const response = await fetchWithTimeout(endpoint, { method: "GET" }, 5000);
            // Qualquer resposta (exceto 404/5xx) prova que o servidor está acessível.
            if (response.status !== 404 && response.status < 500) return true;
            // 5xx: a API está no ar, porém com problema. Não segue para o provisionamento.
            if (response.status >= 500) {
                unhealthy = new Error(`A API respondeu com erro HTTP ${response.status}.`);
                break;
            }
            // 404: este caminho não existe; tenta o próximo.
        } catch (error) {
            lastError = error;
        }
    }

    if (unhealthy) throw unhealthy;

    throw new Error(`Não foi possível confirmar a conexão com a API em ${base}. Verifique o endereço, se o backend está ligado e se o CORS permite a origem do portal.${lastError?.name === "AbortError" ? " A conexão excedeu o tempo limite." : ""}`);
}

provisionForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (!authState.user) {
        showGlobalFeedback("Entre na sua conta para solicitar um provisionamento.");
        openAuthModal();
        return;
    }
    if (state.provisioning) return;

    state.provisioning = true;
    const payload = collectProvisioningPayload();
    const run = state.run = { cancelled: false };
    state.job = { statusUrl: "", cancelUrl: "", canCancel: false, cancelKnown: false, cancelling: false, cancelAccepted: false };

    showProvisioningScreen();
    resetStages();
    updateProgress(0);

    try {
        await verifyApiConnection();
        setStage(0);
        await startApiProvisioning(payload, run);
    } catch (error) {
        if (run.cancelled) return;
        if (error?.clearJob) clearActiveJob();
        showProvisioningError(error);
        state.provisioning = false;
    }
});

// ============================================================
// CONNECTION STRING REVEAL — visual only; API authorization is still required
// ============================================================
const revealConnectionButton = document.getElementById("revealConnection");
const connectionStringElement = document.getElementById("connectionString");
let revealAnimationTimer = null;

function revealConnectionString() {
    if (!state.connectionStringValue) return;
    if (state.connectionRevealed) {
        state.connectionRevealed = false;
        sessionStorage.removeItem("bw_connection_revealed");
        connectionStringElement.textContent = "••••••••••••••••••••••••••••";
        connectionStringElement.classList.add("connection-hidden-value");
        revealConnectionButton.textContent = state.language === "en" ? "REVEAL" : "REVELAR";
        return;
    }
    const value = state.connectionStringValue;
    const chars = "0123456789abcdef:/@.?=&-";
    let visibleCount = 0;
    revealConnectionButton.disabled = true;
    connectionStringElement.classList.remove("connection-hidden-value");
    if (revealAnimationTimer) clearInterval(revealAnimationTimer);
    revealAnimationTimer = setInterval(() => {
        const scrambled = value.split("").map((character, index) => {
            if (index < visibleCount) return character;
            return character === " " ? " " : chars[Math.floor(Math.random() * chars.length)];
        }).join("");
        connectionStringElement.textContent = scrambled;
        visibleCount = Math.min(value.length, visibleCount + Math.max(1, Math.ceil(value.length / 22)));
        if (visibleCount >= value.length) {
            clearInterval(revealAnimationTimer);
            revealAnimationTimer = null;
            connectionStringElement.textContent = value;
            state.connectionRevealed = true;
            sessionStorage.setItem("bw_connection_revealed", "1");
            revealConnectionButton.disabled = false;
            revealConnectionButton.textContent = state.language === "en" ? "HIDE" : "OCULTAR";
        }
    }, 32);
}
revealConnectionButton?.addEventListener("click", revealConnectionString);

// ============================================================
// COPY CONNECTION STRING
// ============================================================

copyConnection.addEventListener(
    "click",
    async () => {

        const connectionString =
            state.connectionStringValue ||
            document.getElementById("connectionString").textContent.trim();

        let copied = false;

        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(connectionString);
                copied = true;
            }
        } catch (error) {
            console.warn("Clipboard API indisponível:", error);
        }

        // Fallback para HTTP (como o portal da rede local).
        if (!copied) {
            const textarea = document.createElement("textarea");
            textarea.value = connectionString;
            textarea.setAttribute("readonly", "");
            textarea.style.position = "fixed";
            textarea.style.left = "-9999px";
            textarea.style.top = "0";
            document.body.appendChild(textarea);
            textarea.select();
            textarea.setSelectionRange(0, textarea.value.length);

            try {
                copied = document.execCommand("copy");
            } catch (error) {
                console.error("Não foi possível copiar:", error);
            }

            document.body.removeChild(textarea);
        }

        if (copied) {
            copyConnection.textContent =
                translations[state.language].copied;

            setTimeout(
                () => {
                    copyConnection.textContent =
                        translations[state.language].copy;
                },
                1500
            );
        } else {
            console.error("Não foi possível copiar a Connection String.");
        }

    }
);


// ============================================================
// BACK TO START AFTER ERROR
// ============================================================

backToStart.addEventListener(
    "click",
    () => {
        state.provisioning = false;
        state.job = null;
        clearActiveJob();
        hideCancelButton();

        if (provisioningAbortController) {
            provisioningAbortController.abort();
            provisioningAbortController = null;
        }

        provisioningScreen.classList.add("hidden");
        resultBox.classList.add("hidden");
        configurationCard.classList.remove("hidden");

        provisioningErrorMessage.classList.add("hidden");
        backToStart.classList.add("hidden");
        provisioningDescription.classList.remove("hidden");

        provisionForm.reset();
        resetStages();
        updateProgress(0);
    }
);


// ============================================================
// NEW ENVIRONMENT
// ============================================================

newEnvironment.addEventListener(
    "click",
    () => {

        state.connectionStringValue = "";
        state.connectionRevealed = false;
        sessionStorage.removeItem("bw_connection_revealed");
        if (revealConnectionButton) revealConnectionButton.disabled = true;
        if (copyConnection) copyConnection.disabled = true;
        if (revealAnimationTimer) { clearInterval(revealAnimationTimer); revealAnimationTimer = null; }

        state.provisioning = false;
        state.job = null;
        clearActiveJob();
        hideCancelButton();

        if (provisioningAbortController) {
            provisioningAbortController.abort();
            provisioningAbortController = null;
        }

        provisioningScreen.classList.add("hidden");
        configurationCard.classList.remove("hidden");

        provisioningErrorMessage.classList.add("hidden");
        backToStart.classList.add("hidden");
        provisioningDescription.classList.remove("hidden");

        provisionForm.reset();

        resultBox.classList.add(
            "hidden"
        );

        resetStages();

        updateProgress(0);

    }
);


// ============================================================
// AMBIENTES — preparado para a API. Não cria estados nem ambientes fictícios.
// GET /environments e GET /environments/{id} são o contrato documentado.
// start/stop são convenções propostas; DELETE usa DELETE /environments/{id}.
// ============================================================
const environmentsButton = document.getElementById("environmentsButton");
const environmentsPage = document.getElementById("environmentsPage");
const refreshEnvironmentsButton = document.getElementById("refreshEnvironments");
const backToProvisioningButton = document.getElementById("backToProvisioning");
const environmentList = document.getElementById("environmentList");
const environmentListStatus = document.getElementById("environmentListStatus");
const environmentDetailsModal = document.getElementById("environmentDetailsModal");
const closeEnvironmentDetailsButton = document.getElementById("closeEnvironmentDetails");
const environmentDetailsTitle = document.getElementById("environmentDetailsTitle");
const environmentDetailsContent = document.getElementById("environmentDetailsContent");
const environmentActionStatus = document.getElementById("environmentActionStatus");
const shutdownEnvironmentButton = document.getElementById("shutdownEnvironment");
const startEnvironmentButton = document.getElementById("startEnvironment");
const openDeleteEnvironmentButton = document.getElementById("openDeleteEnvironment");
const deleteEnvironmentModal = document.getElementById("deleteEnvironmentModal");
const closeDeleteEnvironmentButton = document.getElementById("closeDeleteEnvironment");
const cancelDeleteEnvironmentButton = document.getElementById("cancelDeleteEnvironment");
const deleteEnvironmentNameInput = document.getElementById("deleteEnvironmentName");
const deleteEnvironmentAcknowledgement = document.getElementById("deleteEnvironmentAcknowledgement");
const confirmDeleteEnvironmentButton = document.getElementById("confirmDeleteEnvironment");
const deleteEnvironmentStatus = document.getElementById("deleteEnvironmentStatus");
let currentEnvironment = null;
let currentEnvironmentList = [];
let environmentOperationPending = false;

function updateEnvironmentLanguage() {
    const en = state.language === "en";
    const setText = (id, pt, english) => {
        const el = document.getElementById(id);
        if (el) el.textContent = en ? english : pt;
    };
    const setAria = (id, pt, english) => {
        const el = document.getElementById(id);
        if (el) el.setAttribute("aria-label", en ? english : pt);
    };
    setText("aboutButton", "SOBRE", "ABOUT");
    setText("environmentsTitle", "Ambientes provisionados", "Provisioned environments");
    setText("environmentsDescription", "Consulte e gerencie os ambientes cadastrados.", "View and manage registered environments.");
    setText("refreshEnvironments", "↻ ATUALIZAR", "↻ REFRESH");
    setText("backToProvisioning", "VOLTAR", "BACK");
    setText("environmentListStatus", "Configure e teste a API para consultar os ambientes.", "Configure and test the API to view environments.");
    setAria("closeEnvironmentDetails", "Fechar", "Close");
    setText("environmentDetailsTitle", "Detalhes do ambiente", "Environment details");
    setText("shutdownEnvironment", "DESLIGAR", "STOP");
    setText("openDeleteEnvironment", "EXCLUIR PERMANENTEMENTE", "DELETE PERMANENTLY");
    setAria("closeDeleteEnvironment", "Fechar", "Close");
    setText("deleteEnvironmentTitle", "Excluir ambiente permanentemente", "Permanently delete environment");
    setText("deleteEnvironmentWarning", "Esta ação pode remover as VMs e os recursos associados. Confirme o nome exato do ambiente.", "This action may remove the VMs and associated resources. Confirm the exact environment name.");
    const deleteLabel = document.querySelector('label[for="deleteEnvironmentName"]');
    if (deleteLabel && !currentEnvironment) deleteLabel.textContent = en ? "Enter the exact environment name to confirm deletion" : "Digite o nome do ambiente para confirmar a exclusão";
    const deleteInput = document.getElementById("deleteEnvironmentName");
    if (deleteInput && !currentEnvironment) deleteInput.placeholder = en ? "Exact environment name" : "Nome exato do ambiente";
    const ack = document.querySelector(".delete-acknowledgement");
    if (ack) {
        const checkbox = ack.querySelector("input");
        ack.textContent = en ? " I understand this action is permanent." : " Entendo que esta ação é permanente.";
        if (checkbox) ack.prepend(checkbox);
    }
    setText("cancelDeleteEnvironment", "CANCELAR", "CANCEL");
    setText("confirmDeleteEnvironment", "EXCLUIR PERMANENTEMENTE", "DELETE PERMANENTLY");
    const detailsTag = document.querySelector("#environmentDetailsModal .modal-tag");
    if (detailsTag) detailsTag.textContent = en ? "BLACKWALL / ENVIRONMENTS" : "BLACKWALL / AMBIENTES";
    const deleteTag = document.querySelector("#deleteEnvironmentModal .modal-tag");
    if (deleteTag) deleteTag.textContent = en ? "BLACKWALL / PERMANENT ACTION" : "BLACKWALL / AÇÃO PERMANENTE";
    if (currentEnvironmentList.length && environmentList && !environmentListStatus.classList.contains("loading")) renderEnvironmentList(currentEnvironmentList);
    if (currentEnvironment && environmentDetailsModal && !environmentDetailsModal.classList.contains("hidden")) renderEnvironmentDetails(currentEnvironment);
}

function updateHelpLanguage() {
    const en = state.language === "en";
    const copy = en ? {
        button:"HELP", title:"How to configure your environment", intro:"Understand what each field defines before requesting provisioning.",
        nodeTitle:"What is a node?", nodeText:"A node is a virtual machine that participates in the MongoDB Replica Set. Every environment uses exactly 3 nodes.",
        perNodeTitle:"Resources for the whole environment", perNodeText:"The vCPU, memory, and storage entered here represent the total for the entire environment, not per node. The API calculates and distributes these resources across the 3 nodes according to provisioning rules.",
        fieldsTitle:"What to enter", fields:["Environment name: identifier, for example customer-prod.","vCPU: total processing capacity for the environment.","Memory: total RAM for the environment.","Storage: total disk space for the environment.","Network: network the machines will connect to.","MongoDB: version to install.","Replica Set: fixed at 3 nodes; the API configures them automatically."],
        beforeTitle:"Before provisioning", beforeText:"The API checks local capacity and placement and cost rules. Entering resources does not guarantee availability; the request may be rejected if capacity is unavailable or configured rules are not met.", close:"Close"
    } : {
        button:"AJUDA", title:"Como configurar seu ambiente", intro:"Entenda o que cada campo define antes de solicitar o provisionamento.",
        nodeTitle:"O que é um nó?", nodeText:"Um nó é uma máquina virtual que participa do Replica Set do MongoDB. Cada ambiente terá exatamente 3 nós.",
        perNodeTitle:"Recursos do ambiente completo", perNodeText:"vCPU, memória e armazenamento informados aqui representam o total do ambiente completo, não os recursos por nó. A API calculará e distribuirá esses recursos entre os 3 nós conforme as regras de provisionamento.",
        fieldsTitle:"O que preencher", fields:["Nome do ambiente: identificador, por exemplo cliente-prod.","vCPU: capacidade total de processamento do ambiente.","Memória: RAM total do ambiente.","Armazenamento: espaço total em disco do ambiente.","Rede: rede à qual as máquinas serão conectadas.","MongoDB: versão a instalar.","Replica Set: fixo em 3 nós; a API os configura automaticamente."],
        beforeTitle:"Antes de provisionar", beforeText:"A API verificará a capacidade local e as regras de destino e custo. Preencher os recursos não garante disponibilidade; a solicitação pode ser recusada se não houver capacidade ou se as regras configuradas não forem atendidas.", close:"Fechar"
    };
    const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
    set("helpButtonText", copy.button); set("helpTitle", copy.title); set("helpIntro", copy.intro);
    set("helpNodeTitle", copy.nodeTitle); set("helpNodeText", copy.nodeText); set("helpPerNodeTitle", copy.perNodeTitle); set("helpPerNodeText", copy.perNodeText);
    set("helpFieldsTitle", copy.fieldsTitle); set("helpBeforeTitle", copy.beforeTitle); set("helpBeforeText", copy.beforeText);
    const list = document.getElementById("helpFieldsList");
    if (list) {
        const labels = en ? ["Environment name:","vCPU:","Memory:","Storage:","Network:","MongoDB:","Replica Set:"] : ["Nome do ambiente:","vCPU:","Memória:","Armazenamento:","Rede:","MongoDB:","Replica Set:"];
        list.replaceChildren(...copy.fields.map((line, i) => { const li=document.createElement("li"); const strong=document.createElement("strong"); strong.textContent=labels[i]+" "; li.append(strong, document.createTextNode(line.slice(line.indexOf(" ")+1))); return li; }));
    }
    const close = document.getElementById("closeHelp"); if (close) close.setAttribute("aria-label", copy.close);
}

const envText = (pt, en) => state.language === "en" ? en : pt;
function environmentId(environment) {
    return String(environment?.id ?? environment?.environment_id ?? environment?.provision_id ?? environment?.job_id ?? "");
}
function environmentName(environment) {
    return String(environment?.environment_name ?? environment?.name ?? environment?.environment ?? envText("Ambiente sem nome", "Unnamed environment"));
}
function environmentStatus(environment) {
    const raw = String(environment?.status ?? environment?.state ?? "unknown");
    const key = raw.toLowerCase();
    const statusCopy = {
        running: ["Em execução", "Running"], ready: ["Pronto", "Ready"], active: ["Ativo", "Active"], started: ["Iniciado", "Started"], online: ["Online", "Online"],
        stopped: ["Desligado", "Stopped"], shutdown: ["Desligado", "Stopped"], off: ["Desligado", "Stopped"], powered_off: ["Desligado", "Powered off"],
        starting: ["Iniciando", "Starting"], stopping: ["Desligando", "Stopping"], pending: ["Pendente", "Pending"], provisioning: ["Provisionando", "Provisioning"],
        failed: ["Falhou", "Failed"], error: ["Erro", "Error"], unhealthy: ["Com problema", "Unhealthy"], unknown: ["Desconhecido", "Unknown"],
        ligando: ["Ligando", "Starting"], desligado: ["Desligado", "Stopped"], parado: ["Parado", "Stopped"], ativo: ["Ativo", "Active"], ligado: ["Ligado", "Running"]
    };
    return statusCopy[key]?.[state.language === "en" ? 1 : 0] ?? raw;
}
function normalizedEnvironmentStatus(environment) {
    const value = environmentStatus(environment).toLowerCase();
    if (["running", "ready", "active", "started", "online", "ligado", "ativo"].includes(value)) return "running";
    if (["stopped", "shutdown", "off", "powered_off", "desligado", "parado"].includes(value)) return "stopped";
    if (["starting", "stopping", "pending", "provisioning", "restarting", "cancelling"].includes(value)) return "busy";
    if (["failed", "error", "unhealthy"].includes(value)) return "failed";
    return "unknown";
}
function environmentApiMessage(message, type = "") {
    environmentListStatus.textContent = message;
    environmentListStatus.className = `environment-list-status ${type}`.trim();
}
function createEnvironmentElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined && text !== null) element.textContent = String(text);
    return element;
}
function environmentErrorMessage(data, status) {
    return data?.message || data?.detail || `HTTP ${status}`;
}
async function environmentFetch(path, options = {}, timeout = 8000) {
    const base = getApiUrl();
    if (!base) throw new Error(envText("Configure a URL da API no botão API.", "Configure the API URL using the API button."));
    const response = await fetchWithTimeout(`${base}${path}`, {
        ...options,
        headers: authHeaders({ Accept: "application/json", ...(options.headers || {}) })
    }, timeout);
    const data = await readApiResponse(response);
    if (!response.ok) {
        const error = new Error(environmentErrorMessage(data, response.status));
        error.status = response.status;
        throw error;
    }
    return data;
}
function renderEnvironmentList(environments) {
    environmentList.replaceChildren();
    currentEnvironmentList = environments;
    if (!environments.length) {
        environmentApiMessage(envText("A API não retornou ambientes.", "The API returned no environments."));
        return;
    }
    environmentApiMessage(envText(`${environments.length} ambiente(s) encontrado(s).`, `${environments.length} environment(s) found.`), "success");
    environments.forEach(environment => {
        const button = createEnvironmentElement("button", "environment-list-item");
        button.type = "button";
        const main = createEnvironmentElement("span", "environment-list-main");
        main.append(
            createEnvironmentElement("strong", "environment-list-name", environmentName(environment)),
            createEnvironmentElement("small", "environment-list-subtitle",
                `${environment?.type || "MongoDB Replica Set"} · ${Number(environment?.replica_set_nodes ?? environment?.nodes_count ?? environment?.nodes?.length ?? 3)} ${envText("nós", "nodes")}`)
        );
        const side = createEnvironmentElement("span", "environment-list-side");
        const status = createEnvironmentElement("span", `environment-status ${normalizedEnvironmentStatus(environment)}`, environmentStatus(environment));
        side.append(status, createEnvironmentElement("span", "environment-chevron", "›"));
        button.append(main, side);
        button.addEventListener("click", () => openEnvironmentDetails(environment));
        environmentList.append(button);
    });
}
async function refreshEnvironmentList() {
    if (refreshEnvironmentsButton.disabled) return;
    refreshEnvironmentsButton.disabled = true;
    environmentApiMessage(envText("Consultando ambientes na API…", "Loading environments from API…"), "loading");
    try {
        const data = await environmentFetch("/environments");
        const environments = Array.isArray(data) ? data : data?.environments ?? data?.items;
        if (!Array.isArray(environments)) throw new Error(envText("Resposta inválida: esperado uma lista de ambientes.", "Invalid response: expected a list of environments."));
        renderEnvironmentList(environments);
    } catch (error) {
        console.error("Erro ao carregar ambientes:", error);
        const message = error?.status === 404 || error?.status === 405 || error?.status === 501
            ? envText("A API ainda não implementa GET /environments. A tela está pronta, mas a listagem depende desse endpoint.", "The API does not implement GET /environments yet. The interface is ready, but listing requires this endpoint.")
            : /failed to fetch|networkerror|fetch failed/i.test(error?.message || "")
                ? envText("Não foi possível conectar à API. Quando ela estiver ativa, use Atualizar para carregar os ambientes.", "Could not connect to the API. Once it is running, select Refresh to load environments.")
                : (error?.message || envText("Não foi possível consultar a API.", "Could not query the API."));
        environmentList.replaceChildren();
        environmentApiMessage(message, "error");
    } finally {
        refreshEnvironmentsButton.disabled = false;
    }
}
function showEnvironmentDetailValue(label, value) {
    const row = createEnvironmentElement("div", "environment-detail-row");
    row.append(
        createEnvironmentElement("span", "environment-detail-label", label),
        createEnvironmentElement("strong", "environment-detail-value", value ?? envText("Não disponível", "Not available"))
    );
    return row;
}
function renderEnvironmentDetails(environment) {
    currentEnvironment = environment;
    environmentDetailsTitle.textContent = environmentName(environment);
    environmentDetailsContent.replaceChildren();
    const summary = createEnvironmentElement("div", "environment-detail-grid");
    const fields = [
        [envText("Estado", "Status"), environmentStatus(environment)],
        [envText("Identificador", "ID"), environmentId(environment) || envText("Não disponível", "Not available")],
        [envText("Tipo", "Type"), environment?.type || "MongoDB Replica Set"],
        [envText("Nós", "Nodes"), environment?.replica_set_nodes ?? environment?.nodes_count ?? environment?.nodes?.length ?? envText("Não disponível", "Not available")],
        ["vCPU", environment?.vcpu ?? envText("Não disponível", "Not available")],
        [envText("Memória", "Memory"), environment?.memory_gb != null ? `${environment.memory_gb} GB` : envText("Não disponível", "Not available")],
        [envText("Armazenamento", "Storage"), environment?.storage_gb != null ? `${environment.storage_gb} GB` : envText("Não disponível", "Not available")],
        ["MongoDB", environment?.mongodb_version ?? envText("Não disponível", "Not available")],
        [envText("Rede", "Network"), environment?.network ?? envText("Não disponível", "Not available")],
        [envText("Saúde do Replica Set", "Replica Set health"), environment?.replica_set_health ?? environment?.health ?? envText("Não coletada", "Not reported")]
    ];
    fields.forEach(([label, value]) => summary.append(showEnvironmentDetailValue(label, value)));
    environmentDetailsContent.append(summary);

    const metrics = environment?.metrics;
    environmentDetailsContent.append(createEnvironmentElement("h3", "environment-subheading", envText("Métricas", "Metrics")));
    const metricsGrid = createEnvironmentElement("div", "environment-detail-grid");
    [
        ["CPU", metrics?.cpu_percent != null ? `${metrics.cpu_percent}%` : envText("Não coletada", "Not reported")],
        [envText("Memória usada", "Memory used"), metrics?.memory_used_gb != null ? `${metrics.memory_used_gb} GB` : envText("Não coletada", "Not reported")],
        [envText("Armazenamento usado", "Storage used"), metrics?.storage_used_gb != null ? `${metrics.storage_used_gb} GB` : envText("Não coletado", "Not reported")]
    ].forEach(([label, value]) => metricsGrid.append(showEnvironmentDetailValue(label, value)));
    environmentDetailsContent.append(metricsGrid);

    const connection = createEnvironmentElement("div", "environment-connection");
    connection.append(createEnvironmentElement("h3", "environment-subheading", "Connection string"));
    const value = environment?.connection_string ?? environment?.connectionString;
    const code = createEnvironmentElement("code", "environment-connection-masked", "••••••••••••••••••••••••");
    connection.append(code);
    if (typeof value === "string" && value) {
        const actions = createEnvironmentElement("div", "connection-actions");
        const reveal = createEnvironmentElement("button", "secondary-button compact-button", envText("REVELAR", "REVEAL"));
        const copy = createEnvironmentElement("button", "secondary-button compact-button", envText("COPIAR", "COPY"));
        reveal.type = copy.type = "button";
        reveal.addEventListener("click", () => {
            if (code.dataset.revealed === "true") {
                code.textContent = "••••••••••••••••••••••••";
                code.dataset.revealed = "false";
                reveal.textContent = envText("REVELAR", "REVEAL");
            } else {
                animateConnectionReveal(code, value, () => {
                    code.dataset.revealed = "true";
                    reveal.textContent = envText("OCULTAR", "HIDE");
                });
            }
        });
        copy.addEventListener("click", async () => {
            try {
                await navigator.clipboard.writeText(value);
                environmentActionStatus.textContent = envText("Connection string copiada.", "Connection string copied.");
                environmentActionStatus.className = "environment-action-status success";
            } catch {
                environmentActionStatus.textContent = envText("Não foi possível copiar a connection string.", "Could not copy the connection string.");
                environmentActionStatus.className = "environment-action-status error";
            }
        });
        actions.append(reveal, copy);
        connection.append(actions);
    } else {
        const load = createEnvironmentElement("button", "secondary-button compact-button", envText("CONSULTAR CONNECTION STRING", "LOAD CONNECTION STRING"));
        load.type = "button";
        load.addEventListener("click", async () => {
            load.disabled = true;
            try {
                // Endpoint opcional: só é usado se a API o implementar.
                const data = await environmentFetch(`/environments/${encodeURIComponent(environmentId(environment))}/connection-string`);
                const fetchedValue = data?.connection_string ?? data?.connectionString;
                if (typeof fetchedValue !== "string" || !fetchedValue) throw new Error(envText("A API não retornou a connection string.", "The API did not return a connection string."));
                environment.connection_string = fetchedValue;
                renderEnvironmentDetails(environment);
            } catch (error) {
                environmentActionStatus.textContent = error?.status === 404 || error?.status === 405 || error?.status === 501
                    ? envText("A API ainda não oferece consulta separada da connection string.", "The API does not offer a separate connection-string endpoint yet.")
                    : (error?.message || envText("Falha ao consultar connection string.", "Could not load connection string."));
                environmentActionStatus.className = "environment-action-status error";
            } finally { load.disabled = false; }
        });
        connection.append(load);
    }
    environmentDetailsContent.append(connection);

    const nodes = Array.isArray(environment?.nodes) ? environment.nodes : [];
    if (nodes.length) {
        environmentDetailsContent.append(createEnvironmentElement("h3", "environment-subheading", envText("Nós do Replica Set", "Replica Set nodes")));
        const nodeList = createEnvironmentElement("div", "environment-node-list");
        nodes.forEach((node, index) => {
            const row = createEnvironmentElement("div", "environment-node-row");
            row.append(
                createEnvironmentElement("strong", "", node?.name || node?.hostname || `${envText("Nó", "Node")} ${index + 1}`),
                createEnvironmentElement("span", "", node?.status || envText("Estado não informado", "Status not reported"))
            );
            nodeList.append(row);
        });
        environmentDetailsContent.append(nodeList);
    }

    const normalized = normalizedEnvironmentStatus(environment);
    shutdownEnvironmentButton.textContent = normalized === "running"
        ? envText("DESLIGAR AMBIENTE", "STOP ENVIRONMENT")
        : normalized === "stopped"
            ? envText("LIGAR AMBIENTE", "START ENVIRONMENT")
            : normalized === "busy"
                ? envText("OPERAÇÃO EM ANDAMENTO…", "OPERATION IN PROGRESS…")
                : envText("STATUS INDISPONÍVEL", "STATUS UNAVAILABLE");
    shutdownEnvironmentButton.disabled = !environmentId(environment) || normalized === "unknown" || normalized === "busy" || environmentOperationPending;
    openDeleteEnvironmentButton.disabled = !environmentId(environment) || environmentOperationPending;
    environmentDetailsModal.classList.remove("hidden");
    environmentActionStatus.textContent = "";
    environmentActionStatus.className = "environment-action-status";
}
async function openEnvironmentDetails(environment) {
    environmentActionStatus.textContent = "";
    environmentActionStatus.className = "environment-action-status";
    const id = environmentId(environment);
    if (!id) { renderEnvironmentDetails(environment); return; }
    try {
        // Detalhes são preferidos; se o endpoint opcional ainda não existir, usa a linha da listagem.
        const detailed = await environmentFetch(`/environments/${encodeURIComponent(id)}`);
        const normalized = detailed?.environment ?? detailed;
        renderEnvironmentDetails({ ...environment, ...normalized });
    } catch (error) {
        if ([404, 405, 501].includes(error?.status)) {
            renderEnvironmentDetails(environment);
        } else {
            renderEnvironmentDetails(environment);
            environmentActionStatus.textContent = envText("Não foi possível atualizar os detalhes pela API; exibindo os dados da listagem.", "Could not refresh details from API; showing list data.");
            environmentActionStatus.className = "environment-action-status error";
        }
    }
}
function animateConnectionReveal(code, value, done) {
    if (revealAnimationTimer) { clearInterval(revealAnimationTimer); revealAnimationTimer = null; }
    const chars = "0123456789abcdef:/@.?=&-";
    let visible = 0;
    const button = code.parentElement?.querySelector("button");
    if (button) button.disabled = true;
    revealAnimationTimer = setInterval(() => {
        code.textContent = value.split("").map((ch, index) => index < visible || ch === " " ? ch : chars[Math.floor(Math.random() * chars.length)]).join("");
        visible = Math.min(value.length, visible + Math.max(1, Math.ceil(value.length / 22)));
        if (visible >= value.length) {
            clearInterval(revealAnimationTimer);
            revealAnimationTimer = null;
            code.textContent = value;
            if (button) button.disabled = false;
            if (done) done();
        }
    }, 32);
}
async function runEnvironmentPowerAction() {
    if (!currentEnvironment || environmentOperationPending) return;
    const id = environmentId(currentEnvironment);
    const normalized = normalizedEnvironmentStatus(currentEnvironment);
    if (!id || !["running", "stopped"].includes(normalized)) return;
    const action = normalized === "running" ? "stop" : "start";
    const confirmText = action === "stop"
        ? envText(`Desligar o ambiente "${environmentName(currentEnvironment)}"? Os recursos e os dados serão preservados.`, `Stop "${environmentName(currentEnvironment)}"? Resources and data will be preserved.`)
        : envText(`Ligar o ambiente "${environmentName(currentEnvironment)}"?`, `Start "${environmentName(currentEnvironment)}"?`);
    if (!window.confirm(confirmText)) return;
    environmentOperationPending = true;
    shutdownEnvironmentButton.disabled = true;
    shutdownEnvironmentButton.textContent = envText("ENVIANDO SOLICITAÇÃO…", "SENDING REQUEST…");
    environmentActionStatus.textContent = action === "stop" ? envText("Solicitando desligamento…", "Requesting shutdown…") : envText("Solicitando inicialização…", "Requesting startup…");
    environmentActionStatus.className = "environment-action-status loading";
    try {
        const data = await environmentFetch(`/environments/${encodeURIComponent(id)}/${action}`, {
            method: "POST",
            headers: authHeaders({ "Content-Type": "application/json" }),
            body: JSON.stringify({})
        }, 15000);
        const returnedEnvironment = data?.environment ?? data;
        if (returnedEnvironment && (returnedEnvironment.status || returnedEnvironment.state)) {
            currentEnvironment = { ...currentEnvironment, ...returnedEnvironment };
            renderEnvironmentDetails(currentEnvironment);
        }
        environmentActionStatus.textContent = data?.message || envText("Solicitação aceita pela API. O estado final será exibido após confirmação.", "Request accepted by API. The final state will appear after confirmation.");
        environmentActionStatus.className = "environment-action-status success";
        // Não inventa o novo estado: busca confirmação no backend.
        await refreshEnvironmentList();
        try {
            const refreshed = await environmentFetch(`/environments/${encodeURIComponent(id)}`);
            const item = refreshed?.environment ?? refreshed;
            renderEnvironmentDetails({ ...currentEnvironment, ...item });
        } catch {
            environmentActionStatus.textContent = data?.message || envText("Solicitação aceita; atualize a lista para confirmar o estado.", "Request accepted; refresh the list to confirm the state.");
        }
    } catch (error) {
        environmentActionStatus.textContent = [404, 405, 501].includes(error?.status)
            ? envText(`A API ainda não implementa POST /environments/{id}/${action}. Nenhuma alteração foi simulada.`, `The API does not implement POST /environments/{id}/${action} yet. No change was simulated.`)
            : (error?.message || envText("Não foi possível executar a operação.", "Could not execute the operation."));
        environmentActionStatus.className = "environment-action-status error";
    } finally {
        environmentOperationPending = false;
        if (currentEnvironment) {
            const normalizedNow = normalizedEnvironmentStatus(currentEnvironment);
            shutdownEnvironmentButton.disabled = !environmentId(currentEnvironment) || !["running", "stopped"].includes(normalizedNow);
            shutdownEnvironmentButton.textContent = normalizedNow === "running" ? envText("DESLIGAR AMBIENTE", "STOP ENVIRONMENT") : normalizedNow === "stopped" ? envText("LIGAR AMBIENTE", "START ENVIRONMENT") : envText("STATUS INDISPONÍVEL", "STATUS UNAVAILABLE");
        }
    }
}
async function submitEnvironmentDelete() {
    const id = environmentId(currentEnvironment);
    if (!id || confirmDeleteEnvironmentButton.disabled) return;
    confirmDeleteEnvironmentButton.disabled = true;
    deleteEnvironmentStatus.textContent = envText("Solicitando exclusão permanente…", "Requesting permanent deletion…");
    deleteEnvironmentStatus.className = "environment-action-status loading";
    try {
        const data = await environmentFetch(`/environments/${encodeURIComponent(id)}`, {
            method: "DELETE",
            headers: authHeaders({ "Content-Type": "application/json" }),
            body: JSON.stringify({ confirmation_name: environmentName(currentEnvironment) })
        }, 15000);
        deleteEnvironmentStatus.textContent = data?.message || envText("A API aceitou a solicitação. Confirme a remoção atualizando a lista.", "The API accepted the request. Confirm removal by refreshing the list.");
        deleteEnvironmentStatus.className = "environment-action-status success";
        deleteEnvironmentModal.classList.add("hidden");
        environmentDetailsModal.classList.add("hidden");
        await refreshEnvironmentList();
    } catch (error) {
        deleteEnvironmentStatus.textContent = error?.status === 404 || error?.status === 405 || error?.status === 501
            ? envText("A API ainda não implementa DELETE /environments/{id}. O ambiente não foi removido pelo portal.", "The API does not implement DELETE /environments/{id} yet. The portal did not remove the environment.")
            : (error?.message || envText("Não foi possível excluir o ambiente.", "Could not delete the environment."));
        deleteEnvironmentStatus.className = "environment-action-status error";
        confirmDeleteEnvironmentButton.disabled = false;
    }
}

environmentsButton?.addEventListener("click", () => {
    configurationCard.classList.add("hidden");
    provisioningScreen.classList.add("hidden");
    resultBox.classList.add("hidden");
    document.querySelector(".hero")?.classList.add("hidden");
    environmentsPage.classList.remove("hidden");
    themeMenu.classList.add("hidden");
    refreshEnvironmentList();
});
backToProvisioningButton?.addEventListener("click", () => {
    environmentsPage.classList.add("hidden");
    document.querySelector(".hero")?.classList.remove("hidden");
    configurationCard.classList.remove("hidden");
});
refreshEnvironmentsButton?.addEventListener("click", refreshEnvironmentList);
closeEnvironmentDetailsButton?.addEventListener("click", () => environmentDetailsModal.classList.add("hidden"));
environmentDetailsModal?.addEventListener("click", event => { if (event.target === environmentDetailsModal) environmentDetailsModal.classList.add("hidden"); });
shutdownEnvironmentButton?.addEventListener("click", runEnvironmentPowerAction);
startEnvironmentButton?.addEventListener("click", async () => {
    if (!currentEnvironment || !authState.user) { openAuthModal(); return; }
    const id = environmentId(currentEnvironment); if (!id) return;
    startEnvironmentButton.disabled = true;
    try { const data = await environmentFetch(`/environments/${encodeURIComponent(id)}/start`, { method: "POST" }, 15000); environmentActionStatus.textContent = data?.message || "Solicitação de inicialização enviada; atualize para confirmar o estado."; environmentActionStatus.className = "environment-action-status success"; await refreshEnvironmentList(); }
    catch (error) { environmentActionStatus.textContent = error.message || "Não foi possível ligar o ambiente."; environmentActionStatus.className = "environment-action-status error"; }
    finally { startEnvironmentButton.disabled = false; }
});
openDeleteEnvironmentButton?.addEventListener("click", () => {
    if (!currentEnvironment) return;
    deleteEnvironmentNameInput.value = "";
    deleteEnvironmentAcknowledgement.checked = false;
    deleteEnvironmentStatus.textContent = "";
    deleteEnvironmentStatus.className = "environment-action-status";
    confirmDeleteEnvironmentButton.disabled = true;
    deleteEnvironmentModal.querySelector("label[for='deleteEnvironmentName']").textContent =
        envText(`Digite o nome exato para confirmar: ${environmentName(currentEnvironment)}`, `Type the exact name to confirm: ${environmentName(currentEnvironment)}`);
    deleteEnvironmentNameInput.placeholder = environmentName(currentEnvironment);
    deleteEnvironmentModal.classList.remove("hidden");
    deleteEnvironmentNameInput.focus();
});
function syncDeleteConfirmation() {
    confirmDeleteEnvironmentButton.disabled = !currentEnvironment ||
        deleteEnvironmentNameInput.value !== environmentName(currentEnvironment) ||
        !deleteEnvironmentAcknowledgement.checked;
}
deleteEnvironmentNameInput?.addEventListener("input", syncDeleteConfirmation);
deleteEnvironmentAcknowledgement?.addEventListener("change", syncDeleteConfirmation);
closeDeleteEnvironmentButton?.addEventListener("click", () => deleteEnvironmentModal.classList.add("hidden"));
cancelDeleteEnvironmentButton?.addEventListener("click", () => deleteEnvironmentModal.classList.add("hidden"));
deleteEnvironmentModal?.addEventListener("click", event => { if (event.target === deleteEnvironmentModal) deleteEnvironmentModal.classList.add("hidden"); });
confirmDeleteEnvironmentButton?.addEventListener("click", submitEnvironmentDelete);

// ============================================================
// BACKGROUND NETWORK AND ABOUT MODAL ANIMATION
// ============================================================
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
const bwCanvas = document.getElementById("bwCanvas");
const bwContext = bwCanvas?.getContext("2d");
let networkFrame = 0;
let networkPoints = [];
let networkResizeTimer = null;
let aboutFrame = 0;
let aboutActive = false;
const aboutModal = document.getElementById("aboutModal");
const helpModal = document.getElementById("helpModal");
const openHelpButton = document.getElementById("openHelp");
const closeHelpButton = document.getElementById("closeHelp");
const helpLogoCanvas = document.getElementById("helpLogoCanvas");
let helpLogoImage = null;
let helpLogoFrame = 0;
let helpLogoX = 34, helpLogoY = 40, helpLogoVX = 1.15, helpLogoVY = 0.82, helpLogoGlitchUntil = 0;
function drawHelpLogo() {
    if (!helpLogoCanvas || !helpModal || helpModal.classList.contains("hidden") || document.hidden) {
        helpLogoFrame = 0;
        return;
    }
    const ctx = helpLogoCanvas.getContext("2d");
    if (!ctx) return;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = window.innerWidth, height = window.innerHeight;
    if (helpLogoCanvas.width !== Math.floor(width * ratio) || helpLogoCanvas.height !== Math.floor(height * ratio)) {
        helpLogoCanvas.width = Math.floor(width * ratio); helpLogoCanvas.height = Math.floor(height * ratio);
        helpLogoCanvas.style.width = `${width}px`; helpLogoCanvas.style.height = `${height}px`;
        helpLogoX = Math.min(helpLogoX, Math.max(0, width - 180));
        helpLogoY = Math.min(helpLogoY, Math.max(0, height - 100));
    }
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0); ctx.clearRect(0, 0, width, height);
    if (!helpLogoImage || !helpLogoImage.complete || !helpLogoImage.naturalWidth) {
        helpLogoImage = new Image(); helpLogoImage.src = currentLogoPath();
        helpLogoImage.onload = () => { if (!helpModal.classList.contains("hidden")) { cancelAnimationFrame(helpLogoFrame); helpLogoFrame = requestAnimationFrame(drawHelpLogo); } };
        return;
    }
    const w = Math.min(300, width * 0.34), h = w * helpLogoImage.naturalHeight / helpLogoImage.naturalWidth;
    helpLogoX += helpLogoVX; helpLogoY += helpLogoVY;
    if (helpLogoX < 0 || helpLogoX + w > width) { helpLogoVX *= -1; helpLogoGlitchUntil = performance.now() + 500; }
    if (helpLogoY < 0 || helpLogoY + h > height) { helpLogoVY *= -1; helpLogoGlitchUntil = performance.now() + 500; }
    helpLogoX = Math.max(0, Math.min(width - w, helpLogoX)); helpLogoY = Math.max(0, Math.min(height - h, helpLogoY));
    const glitch = performance.now() < helpLogoGlitchUntil;
    ctx.save(); ctx.globalAlpha = document.body.dataset.theme === "white" ? (glitch ? 0.12 : 0.07) : (glitch ? 0.27 : 0.18);
    const offset = glitch ? Math.random() * 16 - 8 : 0;
    ctx.drawImage(helpLogoImage, helpLogoX + offset, helpLogoY, w, h);
    if (glitch) { ctx.globalCompositeOperation = "screen"; ctx.globalAlpha = 0.16; ctx.filter = "hue-rotate(160deg)"; ctx.drawImage(helpLogoImage, helpLogoX - offset, helpLogoY, w, h); ctx.filter = "hue-rotate(300deg)"; ctx.drawImage(helpLogoImage, helpLogoX + offset * .5, helpLogoY, w, h); }
    ctx.restore();
    if (!reducedMotion.matches) helpLogoFrame = requestAnimationFrame(drawHelpLogo);
}
function openHelp() {
    helpModal?.classList.remove("hidden"); helpLogoImage = null; helpLogoX = 34; helpLogoY = 40;
    updateHelpLanguage(); cancelAnimationFrame(helpLogoFrame); helpLogoFrame = requestAnimationFrame(drawHelpLogo);
}
function closeHelp() {
    helpModal?.classList.add("hidden"); cancelAnimationFrame(helpLogoFrame); helpLogoFrame = 0;
    const ctx = helpLogoCanvas?.getContext("2d"); if (ctx) ctx.clearRect(0,0,helpLogoCanvas.width,helpLogoCanvas.height);
}
openHelpButton?.addEventListener("click", openHelp);
closeHelpButton?.addEventListener("click", closeHelp);
helpModal?.addEventListener("click", event => { if (event.target === helpModal) closeHelp(); });
window.addEventListener("resize", () => { if (helpModal && !helpModal.classList.contains("hidden")) { cancelAnimationFrame(helpLogoFrame); helpLogoFrame = requestAnimationFrame(drawHelpLogo); } });

const apiLogoCanvas = document.getElementById("apiLogoCanvas");
const apiLogoContext = apiLogoCanvas?.getContext("2d");
let apiLogoImage = null, apiLogoFrame = 0;
let apiLogoX = 30, apiLogoY = 30, apiLogoVX = 1.2, apiLogoVY = 0.85, apiLogoGlitchUntil = 0;
function resizeApiLogoCanvas() {
    if (!apiLogoCanvas || !apiLogoContext) return;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    apiLogoCanvas.width = Math.floor(window.innerWidth * ratio);
    apiLogoCanvas.height = Math.floor(window.innerHeight * ratio);
    apiLogoCanvas.style.width = `${window.innerWidth}px`;
    apiLogoCanvas.style.height = `${window.innerHeight}px`;
    apiLogoContext.setTransform(ratio, 0, 0, ratio, 0, 0);
    apiLogoImage = new Image();
    apiLogoImage.src = currentLogoPath();
}
function drawApiLogo() {
    if (!apiModal || apiModal.classList.contains("hidden") || document.hidden || reducedMotion.matches) return;
    const ctx = apiLogoContext;
    if (!ctx || !apiLogoImage?.complete || !apiLogoImage.naturalWidth) {
        apiLogoFrame = requestAnimationFrame(drawApiLogo);
        return;
    }
    const w = Math.min(300, window.innerWidth * 0.34);
    const h = w * apiLogoImage.naturalHeight / apiLogoImage.naturalWidth;
    apiLogoX += apiLogoVX; apiLogoY += apiLogoVY;
    if (apiLogoX < 0 || apiLogoX + w > window.innerWidth) { apiLogoVX *= -1; apiLogoGlitchUntil = performance.now() + 500; }
    if (apiLogoY < 0 || apiLogoY + h > window.innerHeight) { apiLogoVY *= -1; apiLogoGlitchUntil = performance.now() + 500; }
    apiLogoX = Math.max(0, Math.min(window.innerWidth - w, apiLogoX));
    apiLogoY = Math.max(0, Math.min(window.innerHeight - h, apiLogoY));
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    const glitch = performance.now() < apiLogoGlitchUntil;
    ctx.save(); ctx.globalAlpha = glitch ? 0.25 + Math.random() * 0.1 : 0.18;
    const offset = glitch ? Math.random() * 16 - 8 : 0;
    ctx.drawImage(apiLogoImage, apiLogoX + offset, apiLogoY, w, h);
    if (glitch) {
        ctx.globalCompositeOperation = "screen"; ctx.globalAlpha = 0.18;
        ctx.filter = "hue-rotate(160deg)"; ctx.drawImage(apiLogoImage, apiLogoX - offset, apiLogoY, w, h);
        ctx.filter = "hue-rotate(300deg)"; ctx.drawImage(apiLogoImage, apiLogoX + offset * .5, apiLogoY, w, h);
    }
    ctx.restore(); apiLogoFrame = requestAnimationFrame(drawApiLogo);
}
function openApiLogoAnimation() {
    apiLogoX = 30; apiLogoY = 30; resizeApiLogoCanvas();
    cancelAnimationFrame(apiLogoFrame);
    if (reducedMotion.matches) {
        if (apiLogoContext && apiLogoImage) apiLogoImage.onload = () => apiLogoContext.drawImage(apiLogoImage, 30, 30, Math.min(260, window.innerWidth * .3), 100);
    } else apiLogoFrame = requestAnimationFrame(drawApiLogo);
}
function closeApiLogoAnimation() {
    cancelAnimationFrame(apiLogoFrame); apiLogoFrame = 0;
    if (apiLogoContext) apiLogoContext.clearRect(0, 0, window.innerWidth, window.innerHeight);
}
window.addEventListener("resize", () => {
    if (apiModal && !apiModal.classList.contains("hidden")) {
        resizeApiLogoCanvas(); cancelAnimationFrame(apiLogoFrame);
        if (!reducedMotion.matches) apiLogoFrame = requestAnimationFrame(drawApiLogo);
    }
});

const aboutButton = document.getElementById("aboutButton");
const closeAboutButton = document.getElementById("closeAbout");
const aboutCanvas = document.getElementById("aboutLogoCanvas");
const aboutContext = aboutCanvas?.getContext("2d");
let aboutLogoImage = null;
let aboutX = 30, aboutY = 30, aboutVX = 1.2, aboutVY = 0.85, aboutGlitchUntil = 0;

function currentAccentRgb() {
    return getComputedStyle(document.body).getPropertyValue("--accent-rgb").trim() || "255,47,146";
}
function resizeNetworkCanvas() {
    if (!bwCanvas || !bwContext) return;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    bwCanvas.width = Math.floor(window.innerWidth * ratio);
    bwCanvas.height = Math.floor(window.innerHeight * ratio);
    bwCanvas.style.width = `${window.innerWidth}px`;
    bwCanvas.style.height = `${window.innerHeight}px`;
    bwContext.setTransform(ratio, 0, 0, ratio, 0, 0);
    const count = window.innerWidth < 768 ? 15 : 35;
    networkPoints = Array.from({ length: count }, () => ({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.7,
        vy: (Math.random() - 0.5) * 0.7
    }));
}
function networkShouldRun() {
    const visibleInitial = !document.querySelector(".configuration-card")?.classList.contains("hidden") &&
        !document.getElementById("environmentsPage")?.classList.contains("hidden") === false;
    // Only animate on the initial configuration screen; result/provisioning/about are paused.
    return !document.hidden && !reducedMotion.matches &&
        !document.getElementById("provisioningScreen")?.classList.contains("hidden") === false &&
        !document.getElementById("resultBox")?.classList.contains("hidden") === false &&
        !document.getElementById("environmentsPage")?.classList.contains("hidden") === false &&
        !aboutActive;
}
function isInitialScreenVisible() {
    return !document.hidden && !reducedMotion.matches && !aboutActive &&
        !configurationCard?.classList.contains("hidden") &&
        provisioningScreen?.classList.contains("hidden") &&
        resultBox?.classList.contains("hidden") &&
        environmentsPage?.classList.contains("hidden");
}
function drawNetwork() {
    if (!bwCanvas || !bwContext || !isInitialScreenVisible()) {
        networkFrame = 0;
        return;
    }
    const ctx = bwContext;
    const width = window.innerWidth, height = window.innerHeight;
    ctx.clearRect(0, 0, width, height);
    const whiteTheme = document.body.dataset.theme === "white";
    const rgb = whiteTheme ? "15,15,15" : currentAccentRgb();
    for (const p of networkPoints) {
        p.x += p.vx * 0.5; p.y += p.vy * 0.5;
        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;
        p.x = Math.max(0, Math.min(width, p.x));
        p.y = Math.max(0, Math.min(height, p.y));
    }
    for (let i = 0; i < networkPoints.length; i++) {
        const a = networkPoints[i];
        for (let j = i + 1; j < networkPoints.length; j++) {
            const b = networkPoints[j];
            const distance = Math.hypot(a.x - b.x, a.y - b.y);
            if (distance < 100) {
                ctx.strokeStyle = `rgba(${rgb},${Math.min(0.4, (1 - distance / 100) * 0.4)})`;
                ctx.lineWidth = 0.7;
                ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
            }
        }
        ctx.fillStyle = `rgba(${rgb},0.85)`;
        ctx.beginPath(); ctx.arc(a.x, a.y, 1.5, 0, Math.PI * 2); ctx.fill();
    }
    networkFrame = requestAnimationFrame(drawNetwork);
}
function currentLogoPath() {
    return document.body.dataset.theme === "blue" ? "assets/blue-logo.png" : `assets/logo-${document.body.dataset.theme || "pink"}.png`;
}
function resizeAboutCanvas() {
    if (!aboutCanvas || !aboutContext) return;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    aboutCanvas.width = Math.floor(window.innerWidth * ratio);
    aboutCanvas.height = Math.floor(window.innerHeight * ratio);
    aboutCanvas.style.width = `${window.innerWidth}px`;
    aboutCanvas.style.height = `${window.innerHeight}px`;
    aboutContext.setTransform(ratio, 0, 0, ratio, 0, 0);
    aboutLogoImage = new Image();
    aboutLogoImage.src = currentLogoPath();
    aboutLogoImage.onload = () => {
        aboutX = Math.min(aboutX, Math.max(0, window.innerWidth - 200));
        aboutY = Math.min(aboutY, Math.max(0, window.innerHeight - 120));
    };
}
function drawAboutLogo() {
    if (!aboutActive || document.hidden || reducedMotion.matches) return;
    const ctx = aboutContext;
    if (!ctx || !aboutLogoImage?.complete || !aboutLogoImage.naturalWidth) {
        aboutFrame = requestAnimationFrame(drawAboutLogo);
        return;
    }
    const w = Math.min(300, window.innerWidth * 0.34);
    const h = w * aboutLogoImage.naturalHeight / aboutLogoImage.naturalWidth;
    aboutX += aboutVX; aboutY += aboutVY;
    if (aboutX < 0 || aboutX + w > window.innerWidth) { aboutVX *= -1; aboutGlitchUntil = performance.now() + 500; }
    if (aboutY < 0 || aboutY + h > window.innerHeight) { aboutVY *= -1; aboutGlitchUntil = performance.now() + 500; }
    aboutX = Math.max(0, Math.min(window.innerWidth - w, aboutX));
    aboutY = Math.max(0, Math.min(window.innerHeight - h, aboutY));
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    const glitch = performance.now() < aboutGlitchUntil;
    ctx.save();
    ctx.globalAlpha = glitch ? 0.25 + Math.random() * 0.1 : 0.18;
    const offset = glitch ? (Math.random() * 16 - 8) : 0;
    ctx.drawImage(aboutLogoImage, aboutX + offset, aboutY, w, h);
    if (glitch) {
        ctx.globalCompositeOperation = "screen";
        ctx.globalAlpha = 0.18;
        ctx.filter = "hue-rotate(160deg)";
        ctx.drawImage(aboutLogoImage, aboutX - offset, aboutY, w, h);
        ctx.filter = "hue-rotate(300deg)";
        ctx.drawImage(aboutLogoImage, aboutX + offset * 0.5, aboutY, w, h);
    }
    ctx.restore();
    aboutFrame = requestAnimationFrame(drawAboutLogo);
}
function openAbout() {
    aboutActive = true;
    aboutModal?.classList.remove("hidden");
    resizeAboutCanvas();
    if (reducedMotion.matches) {
        if (aboutContext && aboutLogoImage) {
            aboutLogoImage.onload = () => aboutContext.drawImage(aboutLogoImage, 30, 30, Math.min(260, window.innerWidth * 0.3), 100);
        }
    } else {
        cancelAnimationFrame(aboutFrame);
        aboutFrame = requestAnimationFrame(drawAboutLogo);
    }
}
function closeAbout() {
    aboutActive = false;
    aboutModal?.classList.add("hidden");
    cancelAnimationFrame(aboutFrame);
    aboutFrame = 0;
    if (aboutContext && aboutCanvas) aboutContext.clearRect(0, 0, window.innerWidth, window.innerHeight);
}
aboutButton?.addEventListener("click", openAbout);
closeAboutButton?.addEventListener("click", closeAbout);
aboutModal?.addEventListener("click", event => { if (event.target === aboutModal) closeAbout(); });
document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
        if (aboutActive) closeAbout();
        closeHelp();
        environmentDetailsModal?.classList.add("hidden");
        deleteEnvironmentModal?.classList.add("hidden");
        apiModal?.classList.add("hidden");
    }
});
function syncVisualAnimations() {
    if (document.hidden || reducedMotion.matches) {
        cancelAnimationFrame(networkFrame); networkFrame = 0;
            cancelAnimationFrame(aboutFrame); aboutFrame = 0;
        return;
    }
    if (isInitialScreenVisible()) {
        if (!networkFrame) networkFrame = requestAnimationFrame(drawNetwork);
        } else {
        cancelAnimationFrame(networkFrame); networkFrame = 0;
        }
    if (aboutActive && !aboutFrame) aboutFrame = requestAnimationFrame(drawAboutLogo);
}
const visualScreenObserver = new MutationObserver(records => {
    const screenIds = new Set(["provisioningScreen", "resultBox", "environmentsPage"]);
    const screenChanged = records.some(record =>
        screenIds.has(record.target.id) ||
        record.target.classList?.contains("configuration-card") ||
        record.target.classList?.contains("hero")
    );
    if (screenChanged) syncVisualAnimations();
});
visualScreenObserver.observe(document.body, {
    subtree: true, attributes: true, attributeFilter: ["class"],
});
document.addEventListener("visibilitychange", syncVisualAnimations);
window.addEventListener("resize", () => {
    if (networkResizeTimer) clearTimeout(networkResizeTimer);
    networkResizeTimer = setTimeout(() => {
        resizeNetworkCanvas();
        resizeAboutCanvas();
    }, 200);
});
reducedMotion.addEventListener?.("change", () => {
    if (reducedMotion.matches) {
        cancelAnimationFrame(networkFrame);
        cancelAnimationFrame(aboutFrame);
        } else {
        syncVisualAnimations();
    }
});
if (bwCanvas && bwContext) {
    resizeNetworkCanvas();
    if (!reducedMotion.matches) syncVisualAnimations();
}

// ============================================================
// INITIALIZATION
// ============================================================

apiUrl.value = getApiUrl();

apiUrl.addEventListener("keydown", event => {
    if (event.key === "Enter") {
        event.preventDefault();
        testApi.click();
    }
});

startWholePortalTranslationObserver();
applyTheme("pink");

updateLanguage();

syncEnvironmentName();
if (getApiUrl()) loadPortalOptions();
resumeActiveJob();


// ============================================================
// ASSISTENTE DE SUPORTE (somente leitura/orientação)
// Contrato previsto: GET /assistant/status e POST /assistant/chat.
// A chave do provedor de IA deve existir somente no backend.
// ============================================================
(() => {
    const toggle = document.getElementById("supportAssistantToggle");
    const panel = document.getElementById("supportAssistantPanel");
    const close = document.getElementById("supportAssistantClose");
    const form = document.getElementById("supportAssistantForm");
    const input = document.getElementById("supportAssistantInput");
    const messages = document.getElementById("supportAssistantMessages");
    const status = document.getElementById("supportAssistantStatus");
    if (!toggle || !panel || !form) return;
    const api = () => (typeof getApiUrl === "function" ? getApiUrl() : "").replace(/\/+$/, "");
    const addMessage = (who, text) => {
        const p = document.createElement("p"); p.className = `support-assistant-message ${who}`; p.textContent = text; messages.appendChild(p); messages.scrollTop = messages.scrollHeight;
    };
    const setStatus = (text) => { if (status) status.textContent = text; };
    let suggestionsAdded = false;
    function addSuggestions() {
        if (suggestionsAdded) return;
        suggestionsAdded = true;
        const wrap = document.createElement("div");
        wrap.className = "support-assistant-suggestions";
        ["Como provisionar um ambiente?", "O que é um nó?"] .forEach(question => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "support-suggestion";
            button.textContent = question;
            button.addEventListener("click", () => {
                input.value = question;
                form.requestSubmit();
            });
            wrap.appendChild(button);
        });
        messages.appendChild(wrap);
    }
    async function checkStatus() {
        if (!api()) { setStatus("Configure a URL da API no botão API"); return; }
        try {
            const response = await fetch(`${api()}/assistant/status`, {headers:{Accept:"application/json"}});
            if (!response.ok) throw new Error("not available");
            const data = await response.json();
            setStatus(data.available ? "Disponível" : "Não configurado");
        } catch { setStatus("Assistente indisponível ou não configurado"); }
    }
    toggle.addEventListener("click", () => { panel.classList.toggle("hidden"); if (!panel.classList.contains("hidden")) { addSuggestions(); checkStatus(); input.focus(); } });
    close?.addEventListener("click", () => panel.classList.add("hidden"));
    form.addEventListener("submit", async (event) => {
        event.preventDefault(); const question = input.value.trim(); if (!question) return;
        addMessage("user", question); input.value = "";
        if (!api()) { addMessage("assistant", "Configure a URL da API no botão API antes de usar o assistente."); return; }
        const send = document.getElementById("supportAssistantSend"); if (send) send.disabled = true;
        try {
            const response = await fetch(`${api()}/assistant/chat`, {method:"POST", headers:authHeaders({"Content-Type":"application/json",Accept:"application/json"}), body:JSON.stringify({message:question})});
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.detail || data.message || "Assistente indisponível.");
            addMessage("assistant", data.reply || data.response || data.message || "A API não retornou uma resposta de suporte.");
        } catch (error) { addMessage("assistant", `Não foi possível consultar o assistente: ${error.message}. Verifique se a API implementa /assistant/chat.`); }
        finally { if (send) send.disabled = false; }
    });
})();
